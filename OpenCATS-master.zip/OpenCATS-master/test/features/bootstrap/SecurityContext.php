<?php

include_once("./lib/DatabaseConnection.php");
include_once("./constants.php");

use Behat\Behat\Tester\Exception\PendingException;
use Behat\Behat\Context\Context;
use Behat\Behat\Context\SnippetAcceptingContext;
use Behat\Gherkin\Node\PyStringNode;
use Behat\Gherkin\Node\TableNode;
use Behat\MinkExtension\Context\MinkContext;
use Behat\Mink\Exception\ExpectationException;
use Behat\Mink\Exception\ElementHtmlException;
use Behat\Mink\Selector\Xpath\Escaper;

define('ADMIN_ID', 1);
/**
 * Defines application features from the security context.
 */
class SecurityContext extends MinkContext implements Context, SnippetAcceptingContext
{
    use \OpenCATS\Tests\Behat\NavigationSteps;

    private $result;
    private $accessLevel;
    private $csrfToken;

    /**
     * Initializes Security context.
     *
     * Every scenario gets its own context instance.
     * You can also pass arbitrary arguments to the
     * context constructor through behat.yml.
     */
    public function __construct()
    {
        $this->csrfToken = '';
    }

    private function extractCSRFTokenFromHTML($html)
    {
        $matchResult = preg_match(
            '/CATSCsrfToken\s*=\s*"(?P<token>[a-f0-9]{64})"/i',
            $html,
            $matches
        );

        if ($matchResult)
        {
            return $matches['token'];
        }

        return false;
    }

    private function updateCSRFTokenFromHTML($html)
    {
        $token = $this->extractCSRFTokenFromHTML($html);
        if ($token !== false)
        {
            $this->csrfToken = $token;
            return true;
        }

        return false;
    }

    private function refreshCSRFTokenFromCurrentPage()
    {
        $this->updateCSRFTokenFromHTML(
            $this->getSession()->getPage()->getContent()
        );
    }

    private function logoutIfPossible()
    {
        $session = $this->getSession();
        if ($session->isStarted())
        {
            $session->reset();
        }
        $this->csrfToken = '';
    }

    /**
     * @Given I am logged in with :accessLevel access level
     */
    public function iAmLoggedInWithAccessLevel($accessLevel)
    {
        $this->accessLevel = $accessLevel;
        switch($accessLevel)
        {
            case 'DISABLED':
                $username = "testerDisabled";
                $password = "opencats-test-security-903";
                break;
            case 'READONLY':
                $username = "testerRead";
                $password = "opencats-test-security-903";
                break;
            case 'EDIT':
                $username = "testerEdit";
                $password = "opencats-test-security-903";
                break;
            case 'DELETE':
                $username = "testerDelete";
                $password = "opencats-test-security-903";
                break;
            case 'DEMO':
                $username = "testerDemo";
                $password = "opencats-test-security-903";
                break;
            case 'ADMIN':
                $username = "testerSA";
                $password = "opencats-test-security-903";
                break;
            case 'MULTI_ADMIN':
                /* Legacy multi-site administration was removed. Keep the
                 * existing security matrix label mapped to site-admin access. */
                $username = "testerSA";
                $password = "opencats-test-security-903";
                break;
            case 'ROOT':
                $username = "testerRoot";
                $password = "opencats-test-security-903";
                break;
            default:
                throw new PendingException();
        }

        $this->logoutIfPossible();
        $this->visitPath('/index.php?m=login');
        $this->fillField('username', $username);
        $this->fillField('password', $password);
        $this->pressButtonAndWaitForNavigation('Login');
        $this->visitPath('/index.php');
        $this->refreshCSRFTokenFromCurrentPage();
    }

    /**
     * @When I do :type request on url :url
     */
    public function whenIDoRequestOnUrl($type, $url)
    {
        switch($type){
            case "GET":
                $this->iDoGETRequest($url);
                break;
            case "POST":
                $this->iDoPOSTRequest($url);
                break;
            default:
                throw new PendingException();
                
        }
    }
    
    /**
     * @When I do POST request :url
     */
    public function iDoPOSTRequest($url, $data = null)
    {
        $url = rtrim($this->getMinkParameter('base_url'), '/') . '/'.$url;
        if ($data === null)
        {
            $data = array('postback' => 'postback');
        }

        if ($this->csrfToken !== '' &&
            is_array($data) &&
            !isset($data['csrfToken']))
        {
            $data['csrfToken'] = $this->csrfToken;
        }

        // use key 'http' even if you send the request to https://...
        $options = array(
            'http' => array(
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n"."Cookie: CATS=".$this->getSession()->getCookie('CATS')."\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data)
            )
        );
        $context  = stream_context_create($options);
        $this->result = file_get_contents($url, false, $context);
        $this->updateCSRFTokenFromHTML($this->result);
    }

   /**
     * @When I do GET request :url
     */
    public function iDoGETRequest($url)
    {
        $opts = array(
            'http'=>array(
            'method'=>"GET",
            'header'=> "Cookie: CATS=".$this->getSession()->getCookie('CATS')."\r\n"
          )
        );

        $context = stream_context_create($opts);
        $url = rtrim($this->getMinkParameter('base_url'), '/') . '/'.$url.'&';
        $this->result = file_get_contents($url, false, $context);
        $this->updateCSRFTokenFromHTML($this->result);
    }

    /**
     * @Then /^the response should  contain "(?P<text>(?:[^"]|\\")*)"$/
     */
    public function theResponseShouldContain($text)
    {
        $response = $this->result;
        $position = strpos($response, $text);
        if($position === false)
        {
            throw new ExpectationException("'".$text."' was not found in the response from this request and it should be", $this->getSession());
        }
    }

    /**
     * @Then `/^the response should not contain "(?P<text>(?:[^"]|\\")*)"$/`
     */
    public function theResponseShouldNotContain($text)
    {
        $response = $this->result;
        $position = strpos($response, $text);
        if($position !== false)
        {
            throw new ExpectationException("'".$text."' was found in the response from this request and it should be not", $this->getSession());
        }
    }

    /**
     * @Then I should  have permission
     */
    public function iShouldHavePermission()
    {
        $this->theResponseShouldNotContain("You don't have permission");
        $this->theResponseShouldNotContain("Invalid user level for action");      
        $this->theResponseShouldNotContain("OpenCATS - Login");
    }

    /**
     * @Then I should not have permission
     */
    public function iShouldNotHavePermission()
    {
        
        if($this->accessLevel == "DISABLED")
        {
            $this->theResponseShouldContain("OpenCATS - Login");
            return;
        }
        $expectedTexts = array("You don't have permission", "Invalid user level for action", "You are not allowed to change your password.", "Invalid request.");
        $response = $this->result;

        foreach ($expectedTexts as &$text)
        {
            $position = strpos($response, $text);
            if($position !== false)
            {
                return;
            }
        }
        throw new ExpectationException("'".$expectedTexts[0]."' was not found in the response from this request and it should be", $this->getSession());
    }    

    /**
     * @When I follow link :name
     */
    public function iFollowLink($name)
    {
        $link = $this->getSession()->getPage()->findLink($name);
        if ($link === null && $this->accessLevel === 'DISABLED')
        {
            return;
        }
        $this->clickLink($name);
    }

    /**
     * @Then /^I should (see|not see) the page heading "([^"]*)"$/
     */
    public function assertPageHeading($visibility, $heading)
    {
        $escaper = new Escaper();
        $xpath = '//h1[normalize-space(.) = ' . $escaper->escapeLiteral($heading) . ']';

        if ($visibility === 'see')
        {
            $this->assertSession()->elementExists('xpath', $xpath);
        }
        else
        {
            $this->assertSession()->elementNotExists('xpath', $xpath);
        }
    }

    /**
     * @Then the page should  contain :text
     */
    public function assertHTMLcontains($text)
    {
        $this->assertSession()->responseContains($text);
    }

    /**
     * @Then the page should not contain :text
     */
    public function assertHTMLnotContains($text)
    {
        $this->assertSession()->responseNotContains($text);
    }

    /**
     * @Then I will log out
     */
    public function iWillLogOut()
    {
        $this->pressButton('Logout');
    }

}
