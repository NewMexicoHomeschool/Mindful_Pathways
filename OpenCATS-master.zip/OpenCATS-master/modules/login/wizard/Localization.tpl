<b>Please select your time zone and date format.</b>
<p />
<div id="localizationBeacon" style="display: none;">&nbsp;</div>
<table class="editTable">
    <tr>
        <td style="font-size: 14px;">Time Zone</td>
        <td style="padding-bottom: 10px;"><?php TemplateUtility::printTimeZoneSelect('timeZone', 'width: 420px;', '', $this->timeZone); ?></td>
    </tr>

    <tr>
        <td style="font-size: 14px;">Date Format</td>
        <td style="font-size: 14px; padding-bottom: 5px;">
            <select id="dateFormat" name="dateFormat" style="width: 150px;">
                <option value="mdy"<?php if ($this->dateFormat == DATE_FORMAT_MMDDYY): ?> selected<?php endif; ?>>MM-DD-YYYY (US)</option>
                <option value="dmy"<?php if ($this->dateFormat == DATE_FORMAT_DDMMYY): ?> selected<?php endif; ?>>DD-MM-YYYY (UK)</option>
                <option value="ymd"<?php if ($this->dateFormat == DATE_FORMAT_YYYYMMDD): ?> selected<?php endif; ?>>YYYY-MM-DD (ISO)</option>
            </select>
        </td>
    </tr>

    <tr>
        <td style="font-size: 14px;">Time Format</td>
        <td style="font-size: 14px; padding-bottom: 5px;">
            <select id="timeFormat" name="timeFormat" style="width: 150px;">
                <option value="12"<?php if (!$this->isTimeFormat24): ?> selected<?php endif; ?>>12-hour (1:30 PM)</option>
                <option value="24"<?php if ($this->isTimeFormat24): ?> selected<?php endif; ?>>24-hour (13:30)</option>
            </select>
        </td>
    </tr>
</table>
<p />
These settings will effect how you see dates and times in OpenCATS.
