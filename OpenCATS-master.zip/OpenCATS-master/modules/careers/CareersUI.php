<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */

include_once(LEGACY_ROOT . '/lib/CareerPortal.php');
include_once(LEGACY_ROOT . '/lib/JobOrders.php');
include_once(LEGACY_ROOT . '/lib/Candidates.php');
include_once(LEGACY_ROOT . '/lib/Site.php');
include_once(LEGACY_ROOT . '/lib/Companies.php');
include_once(LEGACY_ROOT . '/lib/Contacts.php');
include_once(LEGACY_ROOT . '/lib/Users.php');
include_once(LEGACY_ROOT . '/lib/FileUtility.php');
include_once(LEGACY_ROOT . '/lib/ActivityEntries.php');
include_once(LEGACY_ROOT . '/lib/DocumentToText.php');
include_once(LEGACY_ROOT . '/lib/DatabaseConnection.php');
include_once(LEGACY_ROOT . '/lib/DatabaseSearch.php');
include_once(LEGACY_ROOT . '/lib/CommonErrors.php');
include_once(LEGACY_ROOT . '/lib/Questionnaire.php');
include_once(LEGACY_ROOT . '/lib/DocumentToText.php');
include_once(LEGACY_ROOT . '/lib/FileUtility.php');
include_once(LEGACY_ROOT . '/lib/ParseUtility.php');
include_once(LEGACY_ROOT . '/lib/StringUtility.php');

class CareersUI extends UserInterface
{
    private $_bootstrapPortal = false;

    public function __construct()
    {
        parent::__construct();

        $this->_authenticationRequired = false;
        $this->_moduleDirectory = 'careers';
        $this->_moduleName = 'careers';
    }


    public function handleRequest()
    {
        $action = $this->getAction();

        switch ($action)
        {
            default:
                $this->careersPage();
                break;
        }
    }

    private function careersPage()
    {
        global $careerPage;

        /* Get information on what site we are in, our environment, etc. */

        $site = new Site();
        $siteRS = $site->getFirstSite();

        if (!isset($siteRS['name']))
        {
            die('An error has occurred:  No site exists with this site name.');
        }

        $siteName = $siteRS['name'];
        $siteNameEscaped = htmlspecialchars((string) $siteName, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);

        /* Get information on the current template. */

        $careerPortalSettings = new CareerPortalSettings();
        $careerPortalSettingsRS = $careerPortalSettings->getAll();

        $templateName = $careerPortalSettingsRS['activeBoard'];
        $enabled = $careerPortalSettingsRS['enabled'];

        if ($enabled == 0)
        {
            // FIXME: Generate valid XHTML error pages. Create an error/fatal method!
            die('<html><body><!-- Job Board Disabled --></body></html>');
        }

        if (isset($_GET['templateName']))
        {
            $templateName = $_GET['templateName'];
        }

        $template = $careerPortalSettings->getTemplate($templateName);
        // Only templates explicitly opting into the new presentation use Bootstrap.
        $this->_bootstrapPortal = strpos($template['CSS'], '/* OpenCATS Bootstrap 5.3 */') === 0
            && $careerPortalSettingsRS['useCATSTemplate'] === '';

        /* At this point the entire template is loaded, we just need to add data to the
           template for the specific page. */

        /* Get all public job orders for this site. */
        $jobOrders = new JobOrders();
        $rs = $jobOrders->getAll(JOBORDERS_STATUS_SHARE, -1, -1, -1, false, true);

        // Get the get or post page request
        $p = isset($_GET['p']) ? $_GET['p'] : '';
        $p = isset($_POST['p']) ? $_POST['p'] : $p;

        // Get the get or post sub-page request
        $pa = isset($_GET['pa']) ? $_GET['pa'] : '';
        $pa = isset($_POST['pa']) ? $_POST['pa'] : $pa;

        $isRegistrationEnabled = $careerPortalSettingsRS['candidateRegistration'];

        if ($p == 'candidateLogin')
        {
            if (!$isRegistrationEnabled || $_SERVER['REQUEST_METHOD'] !== 'POST'
                || !$this->candidateLogin($template['Content - Candidate Registration'], $jobOrders, $rs))
            {
                CommonErrors::fatal(COMMONERROR_BADFIELDS, $this,
                    'The information supplied could not be verified. Please check your details and try again.');
                return;
            }
            $p = 'applyToJob';
        }

        switch ($pa)
        {
            case 'logout':
                if ($_SERVER['REQUEST_METHOD'] !== 'POST')
                {
                    CommonErrors::fatal(COMMONERROR_BADFIELDS, $this, 'Invalid request.');
                }

                if ($isRegistrationEnabled)
                {
                    unset($_SESSION['careerPortalCandidateID']);
                    session_regenerate_id(true);
                }
                break;

            case 'updateProfile':
                if ($isRegistrationEnabled)
                {
                    $p = 'registeredCandidateProfile';
                }
                break;
        }

        if ($p == 'captcha')
        {
            $this->outputCareerPortalCaptcha();
        }
        else if ($p == 'showAll')
        {
            $template['Content'] = $template['Content - Search Results'];

            $numberOfSearchResultsEscaped = htmlspecialchars((string) count($rs), ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $template['Content'] = str_replace('<numberOfSearchResults>', $numberOfSearchResultsEscaped, $template['Content']);
            $template['Content'] = str_replace('<registeredCandidate>', $isRegistrationEnabled ? $this->getRegisteredCandidateBlock($template['Content - Candidate Registration']) : '', $template['Content']);

            if ($careerPortalSettingsRS['allowBrowse'] == 1)
            {
                /* Legacy. */
                $template['Content'] = str_replace('<searchResultsTableUnformatted>', $this->getResultsTable($rs, $careerPortalSettingsRS, true), $template['Content']);

                while (strpos($template['Content'], '<searchResultsTable') !== false)
                {
                    $searchResultsTablePosition = strpos($template['Content'], '<searchResultsTable');

                    $temp = substr($template['Content'], $searchResultsTablePosition + strlen('<searchResultsTable'));
                    $searchResultsTableParameters = trim(substr($temp, 0, strpos($temp, '>') - 1));

                    $tableHTML = $this->getResultsTable($rs, $careerPortalSettingsRS, false, $searchResultsTableParameters);

                    $template['Content'] = substr($template['Content'], 0, $searchResultsTablePosition - 1) . $tableHTML . substr($temp, strpos($temp, '>') + 1);
                }
            }
            else
            {
                $template['Content'] = str_replace('<searchResultsTable>', 'Sorry, Job Listings have been disabled by the '.$siteNameEscaped.' administrator.', $template['Content']);
            }
        }
        else if ($p == 'search')
        {
        }
        else if ($p == 'registeredCandidateProfile' && $isRegistrationEnabled)
        {
            $content = $template['Content - Candidate Profile'];

            $candidate = $this->getCareerPortalCandidate();
            if ($candidate === false)
            {
                echo '<html><body>You have not registered yet.  Please wait while we direct you to the job list...<script>setTimeout("document.location.href=\'?m=careers&&p=showAll\';", 1500);</script></body></html>';
                die();
            }

            // Get the candidate's latest resume attachment (if exists)
            $attachmentsLib = new Attachments();
            $attachments = $attachmentsLib->getAll(DATA_ITEM_CANDIDATE, $candidate['candidateID']);

            $latestDate = 0;
            $latestAttachment = false;
            foreach ($attachments as $attachment)
            {
                if (preg_match('/^([0-9]{2})-([0-9]{2})-([0-9]{2}) \(([0-9]{2}):([0-9]{2}):([0-9]{2}) [A-Z]{2}\)$/',
                    $attachment['dateCreated'], $matches))
                {
                    $epoch = strtotime( strval($matches[1]) . '/' . strval($matches[2]) . '/' . strval($matches[3]) );

                    if ($epoch > $latestDate)
                    {
                        $latestDate = $epoch;
                        $latestAttachment = $attachment['attachmentID'];
                    }
                }
            }

            // Get their latest resume
            if ($latestAttachment !== false)
            {
                $candidatesLib = new Candidates();
                $myResume = $candidatesLib->getResume($latestAttachment);
            }

            /* Replace input fields. */
            $firstNameEscaped = htmlspecialchars((string) $candidate['firstName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $lastNameEscaped = htmlspecialchars((string) $candidate['lastName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $addressEscaped = htmlspecialchars((string) $candidate['address'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $address2Escaped = htmlspecialchars((string) $candidate['address2'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $cityEscaped = htmlspecialchars((string) $candidate['city'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $stateEscaped = htmlspecialchars((string) $candidate['state'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $zipEscaped = htmlspecialchars((string) $candidate['zip'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $phoneWorkEscaped = htmlspecialchars((string) $candidate['phoneWork'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $email1Escaped = htmlspecialchars((string) $candidate['email1'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $phoneHomeEscaped = htmlspecialchars((string) $candidate['phoneHome'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $phoneCellEscaped = htmlspecialchars((string) $candidate['phoneCell'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $bestTimeToCallEscaped = htmlspecialchars((string) $candidate['bestTimeToCall'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $keySkillsEscaped = htmlspecialchars((string) $candidate['keySkills'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $sourceEscaped = htmlspecialchars((string) $candidate['source'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $currentEmployerEscaped = htmlspecialchars((string) $candidate['currentEmployer'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $resumeTextEscaped = $latestAttachment !== false
                ? htmlspecialchars((string) DatabaseSearch::fulltextDecode($myResume['text']), ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING)
                : '';
            $content = str_replace('<input-firstName>', '<input name="firstName" id="firstName" class="inputBoxName' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $firstNameEscaped . '" />', $content);
            $content = str_replace('<input-lastName>', '<input name="lastName" id="lastName" class="inputBoxName' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $lastNameEscaped . '" />', $content);
            $content = str_replace('<input-address>', '<input name="address" id="address" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $addressEscaped . '" />', $content);
            $content = str_replace('<input-address2>', '<input name="address2" id="address2" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $address2Escaped . '" />', $content);
            $content = str_replace('<input-city>', '<input name="city" id="city" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $cityEscaped . '" />', $content);
            $content = str_replace('<input-state>', '<input name="state" id="state" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $stateEscaped . '" />', $content);
            $content = str_replace('<input-zip>', '<input name="zip" id="zip" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $zipEscaped . '" />', $content);
            $countrySelectHTML = TemplateUtility::getCountrySelectHTML(
                'country',
                (string) $candidate['country'],
                true,
                ($this->_bootstrapPortal ? 'form-select' : 'inputBoxNormal'),
                ''
            );
            $content = str_replace('<input-country>', $countrySelectHTML, $content);
            $content = str_replace('<input-country req>', $countrySelectHTML, $content);
            $content = str_replace('<input-phoneWork>', '<input name="phoneWork" id="phoneWork" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $phoneWorkEscaped . '" />', $content);
            $content = str_replace('<input-email1>', '<input name="email1" id="email1" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $email1Escaped . '" />', $content);
            $content = str_replace('<input-phoneHome>', '<input name="phoneHome" id="phoneHome" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $phoneHomeEscaped . '" />', $content);
            $content = str_replace('<input-phoneCell>', '<input name="phoneCell" id="phoneCell" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $phoneCellEscaped . '" />', $content);
            $content = str_replace('<input-bestTimeToCall>', '<input name="bestTimeToCall" id="bestTimeToCall" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $bestTimeToCallEscaped . '" />', $content);
            $content = str_replace('<input-keySkills>', '<input name="keySkills" id="keySkills" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $keySkillsEscaped . '" />', $content);
            $content = str_replace('<input-source>', '<input name="source" id="source" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $sourceEscaped . '" />', $content);
            $content = str_replace('<input-currentEmployer>', '<input name="currentEmployer" id="currentEmployer" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $currentEmployerEscaped . '" />', $content);
            $content = str_replace('<input-resume>',
                ($this->_bootstrapPortal ? '<label class="form-label d-block">My Resume' : '<strong>My Resume</strong><br />')
                . '<textarea name="resumeContents" class="inputBoxArea' . ($this->_bootstrapPortal ? ' form-control' : '') . '" ' . ($this->_bootstrapPortal ? '' : 'style="width: 400px; height: 200px;"') . ' readonly>'
                . $resumeTextEscaped .'</textarea>'
                . ($this->_bootstrapPortal ? '</label><label class="form-label d-block mt-3" for="file">Upload new resume:</label>' : '<br /><br /><strong>Upload new resume:</strong><br /> ')
                . '<input type="file" name="file" id="file" type="file" class="inputBoxFile' . ($this->_bootstrapPortal ? ' form-control' : '') . '" size="45" />',
                $content
            );
            $content = str_replace('<input-submit>', '<input type="submit" name="submitButton" id="submitButton" class="submitButton' . ($this->_bootstrapPortal ? ' btn btn-primary' : '') . '" onclick="document.getElementById(\'submitButton\').disabled=true;" value="Save Profile" ' . ($this->_bootstrapPortal ? '' : 'style="width: 150px;"') . ' />', $content);

            $attachmentIDValue = $latestAttachment ? $latestAttachment : -1;
            $content = sprintf(
                '<form name="updateForm" id="updateForm" enctype="multipart/form-data" method="post" '
                . 'action="%s?m=careers&p=onRegisteredCandidateProfile">',
                CATSUtility::getIndexName()
            ) . '<input type="hidden" name="attachmentID" value="' . $attachmentIDValue . '" />'
            . $content . '</form>'
            . (isset($_GET[$id='isPostBack']) && !strcmp($_GET[$id], 'yes') ? '<script language="javascript" type="text/javascript">setTimeout(\'alert("Your changes have been saved!")\',25);</script>' : '');

            $template['Content'] = $content;
        }
        else if ($p == 'onRegisteredCandidateProfile' && $isRegistrationEnabled)
        {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST')
            {
                CommonErrors::fatal(COMMONERROR_BADFIELDS, $this, 'Invalid request.');
            }

            $candidate = $this->getCareerPortalCandidate();
            if ($candidate === false)
            {
                echo '<html><body>You have not registered yet.  Please wait while we direct you to the job list...<script>setTimeout("document.location.href=\'?m=careers&&p=showAll\';", 1500);</script></body></html>';
                die();
            }

            // Get the fields (if included in the template) to update
            $fields = array('firstName', 'lastName', 'email1', 'phoneHome', 'phoneCell', 'phoneWork', 'address', 'address2',
                'country', 'city', 'state', 'zip', 'keySkills', 'currentEmployer', 'bestTimeToCall'
            );
            $fieldValues = array();

            foreach ($fields as $field)
            {
                if (isset($_POST[$field]) && $_POST[$field] != '')
                {
                    eval('$'.$field.' = trim($_POST[\''.$field.'\']);');
                    $fieldValues[$field] = $_POST[$field];
                }
                else
                {
                    eval('$'.$field.' = $candidate[\''.$field.'\'];');
                    $fieldValues[$field] = $candidate[$field];
                }
            }
            $country = strtoupper(trim((string) $country));
            if ($country != '' && !isset($GLOBALS['countries'][$country]))
            {
                $country = '';
            }
            $fieldValues['country'] = $country;

            // Get the attachment to replace (if exists)
            $attachmentID = false;
            if (isset($_POST['attachmentID']))
            {
                if (!$this->isOptionalIDValid('attachmentID', $_POST))
                {
                    CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'Invalid attachment ID.');
                }

                $attachmentID = $_POST['attachmentID'] != '-1' ? $_POST['attachmentID'] : false;
            }

            $attachmentsLib = new Attachments();
            $candidatesLib = new Candidates();

            // Update the candidate's information
            $candidatesLib->update(
                $candidate['candidateID'],
                $candidate['isActive'] ? true : false,
                $firstName,
                $candidate['middleName'],
                $lastName,
                $email1,
                $email1,
                $phoneHome,
                $phoneCell,
                $phoneWork,
                $address,
                $address2,
                $city,
                $state,
                $zip,
                $candidate['source'],
                $keySkills,
                $candidate['dateAvailable'],
                $currentEmployer,
                $candidate['canRelocate'],
                $candidate['currentPay'],
                $candidate['desiredPay'],
                $candidate['notes'],
                $candidate['webSite'],
                $bestTimeToCall,
                $candidate['owner'],
                $candidate['isHot'] ? true : false,
                '',
                '',
                $candidate['eeoGender'],
                $candidate['eeoEthnicType'],
                $candidate['eeoVeteranType'],
                $candidate['eeoDisabilityStatus'],
                $country
            );

            $uploadResume = FileUtility::getUploadFileFromPost('careerportaladd', 'file');
            if ($uploadResume !== false)
            {
                $uploadPath = FileUtility::getUploadFilePath('careerportaladd', $uploadResume);
                if ($uploadPath !== false)
                {
                    // Replace most current resume with new uploaded resume
                    $attachmentsLib->delete($attachmentID, true);
                    $attachmentCreator = new AttachmentCreator();
                    $attachmentCreator->createFromFile(DATA_ITEM_CANDIDATE, $candidate['candidateID'],
                        $uploadPath, false, '', true, true
                    );
                }
            }

            $template['Content'] = '<div id="careerContent"><br /><br /><h1>Please wait while you are redirected to your updated profile...</h1></div>';
            CATSUtility::transferRelativeURI('m=careers&p=showAll&pa=updateProfile&isPostBack=yes');
        }
        else if ($p == 'candidateRegistration' && $isRegistrationEnabled)
        {
            $content = $template['Content - Candidate Registration'];

            $jobID = intval($_GET['ID']);
            $jobOrderData = $jobOrders->get($jobID);
            $jobTitleEscaped = htmlspecialchars((string) $jobOrderData['title'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);

            $content = str_replace(array('<applyContent>','</applyContent>'), '', $content);

            $content = str_replace(array('<input-captcha>', '<input-captcha req>'), '', $content);
            $content = str_replace('<input-submit>', $this->getCareerPortalCaptchaInput() . '<input-submit>', $content);

            $content = str_replace(
                '<input-submit>',
                '<input type="submit"' . ($this->_bootstrapPortal ? ' class="btn btn-primary"' : '')
                . ' id="submitButton" name="submitButton" value="Continue to Application" />',
                $content
            );

            $content = str_replace(
                '<input-new>',
                '<input type="radio"' . ($this->_bootstrapPortal ? ' class="form-check-input"' : '')
                . ' id="isNewYes" name="isNew" value="yes" onchange="isCandidateRegisteredChange();" checked />',
                                   $content
            );

            $content = str_replace(
                '<input-registered>',
                '<input type="radio"' . ($this->_bootstrapPortal ? ' class="form-check-input"' : '')
                . ' id="isNewNo" name="isNew" value="no" onchange="isCandidateRegisteredChange();" />',
                                   $content
            );

            // Also remove the legacy label in templates already stored in the database.
            $content = str_replace(
                array('<input-rememberMe>', 'Remember my information for future visits'),
                                   '',
                                   $content
            );
            $content = str_replace('<title>', $jobTitleEscaped, $content);

            // Process html-ish fields like <input-firstName> into the proper form
            $content = preg_replace(
                '/\<input\-([A-Za-z0-9]+)\>/',
                '<input type="text" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" ' . ($this->_bootstrapPortal ? '' : 'style="width: 270px;"') . ' name="$1" id="$1" onfocus="onFocusFormField(this)" />',
                $content
            );

            // Insert the form block
            $content = sprintf(
                '<form name="register" id="register" method="post" onsubmit="return validateCandidateRegistration()" '
                . 'action="%s?m=careers&amp;p=candidateLogin&amp;ID=%d">',
                CATSUtility::getIndexName(),
                $jobID
            ) . $content . '<script>enableFormFields(false);</script></form>';

            $template['Content'] = $content;
        }
        else if ($p == 'applyToJob' || isset($_POST[$id='applyToJobSubAction']) && $_POST[$id] != '')
        {
            // Pre-populations
            $firstName = isset($_POST[$id='firstName']) ? $_POST[$id] : '';
            $lastName = isset($_POST[$id='lastName']) ? $_POST[$id] : '';
            $address = isset($_POST[$id='address']) ? $_POST[$id] : '';
            $address2 = isset($_POST[$id='address2']) ? $_POST[$id] : '';
            $city = isset($_POST[$id='city']) ? $_POST[$id] : '';
            $state = isset($_POST[$id='state']) ? $_POST[$id] : '';
            $zip = isset($_POST[$id='zip']) ? $_POST[$id] : '';
            $country = isset($_POST[$id='country']) ? $_POST[$id] : '';
            $phone = isset($_POST[$id='phone']) ? $_POST[$id] : '';
            $email = isset($_POST[$id='email']) ? $_POST[$id] : '';
            $phoneHome = isset($_POST[$id='phoneHome']) ? $_POST[$id] : '';
            $phoneCell = isset($_POST[$id='phoneCell']) ? $_POST[$id] : '';
            $bestTimeToCall = isset($_POST[$id='bestTimeToCall']) ? $_POST[$id] : '';
            $email2 = isset($_POST[$id='email2']) ? $_POST[$id] : '';
            $emailconfirm = isset($_POST[$id='emailconfirm']) ? $_POST[$id] : '';
            $keySkills = isset($_POST[$id='keySkills']) ? $_POST[$id] : '';
            $source = isset($_POST[$id='source']) ? $_POST[$id] : '';
            $employer = isset($_POST[$id='employer']) ? $_POST[$id] : '';
            // for <input-resumeUploadPreview>
            $resumeContents = isset($_POST[$id='resumeContents']) ? $_POST[$id] : '';
            $resumeFileLocation = isset($_POST[$id='file']) ? $_POST[$id] : '';
            // for returning candidates
            $candidateID = -1;

            if ($isRegistrationEnabled)
            {
                // Check if the user is registered and logged in
                $candidate = $this->getCareerPortalCandidate();
                if ($candidate !== false)
                {
                    // The candidate is registered
                    $firstName = $candidate['firstName']; $lastName = $candidate['lastName'];
                    $address = $candidate['address'];
                    $address2 = $candidate['address2'];
                    $city = $candidate['city'];
                    $state = $candidate['state'];
                    $zip = $candidate['zip'];
                    if (!isset($_POST['country']))
                    {
                        $country = $candidate['country'];
                    }
                    $phone = $candidate['phoneWork'];
                    $phoneHome = $candidate['phoneHome'];
                    $phoneCell = $candidate['phoneCell'];
                    $email = $candidate['email1'];
                    $email2 = $candidate['email2'];
                    $emailconfirm = $email;
                    $keySkills = $candidate['keySkills'];
                    $source = $candidate['source'];
                    $employer = $candidate['currentEmployer'];
                    $candidateID = $candidate['candidateID'];
                }
            }

            /**
             * SUB-ACTIONS
             * These actions are called as postbacks, such as loading a resume file into the
             * "contents" textarea on the application page. All post data remains intact and
             * re-populates the fields giving the illusion of AJAX.
             */
            if (isset($_POST[$id='applyToJobSubAction']) && strlen($subAction = $_POST[$id]))
            {
                // Check if a file has been uploaded, if so populate the contents textarea
                if (($uploadFile = FileUtility::getUploadFileFromPost('careerportaladd', 'resumeFile')) !== false)
                {
                    $uploadFilePath = FileUtility::getUploadFilePath('careerportaladd', $uploadFile);

                    if ($uploadFilePath !== false)
                    {
                        $d2t = new DocumentToText();
                        $docType = $d2t->getDocumentType($uploadFilePath);
                        if ($d2t->convert($uploadFilePath, $docType) !== false)
                        {
                            $resumeContents = $d2t->getString();
                            // Remove nasty things like _rATr in favor of @
                            $resumeContents = DatabaseSearch::fulltextDecode($resumeContents);
                        }
                        else
                        {
                            $resumeContents = 'Unable to load your resume contents. Your resume will '
                                . 'still be uploaded and attached to your application.';
                        }
                        $resumeFileLocation = $uploadFile;
                    }
                }

                if (!strcmp($subAction, 'resumeParse'))
                {
                    // Check if the resume contents need to be parsed (user clicked parse contents button)
                    $pu = new ParseUtility();
                    $fileName = isset($uploadFile) ? $uploadFile : '';
                    $res = $pu->documentParse($fileName, strlen($resumeContents), '', $resumeContents);
                    if (is_array($res) && !empty($res))
                    {
                        if (isset($res[$id='first_name']) && $res[$id] != '' && $firstName == '') $firstName = $res[$id];
                        if (isset($res[$id='last_name']) && $res[$id] != '' && $lastName == '') $lastName = $res[$id];
                        if (isset($res[$id='us_address']) && $res[$id] != '' && $address == '') $address = $res[$id];
                        if (isset($res[$id='city']) && $res[$id] != '' && $city == '') $city = $res[$id];
                        if (isset($res[$id='state']) && $res[$id] != '' && $state == '') $state = $res[$id];
                        if (isset($res[$id='zip_code']) && $res[$id] != '' && $zip == '') $zip = $res[$id];
                        if (isset($res[$id='email_address']) && $res[$id] != '' && $email == '') { $email = $res[$id]; $email2 = $res[$id]; $emailconfirm = $res[$id]; }
                        if (isset($res[$id='phone_number']) && $res[$id] != '' && $phone == '') $phone = $res[$id];
                        if (isset($res[$id='skills']) && $res[$id] != '' && $keySkills == '') $keySkills = $res[$id];
                    }
                }
            }

            $template['Content'] = $template['Content - Apply for Position'];

            // Force integer
            // FIXME: Input validation, and use isRequiredIDValid() to check for / force integer.
            $jobID = intval(isset($_GET['ID']) ? $_GET['ID'] : $_POST['ID']);

            $jobOrderData = $jobOrders->get($jobID);
            if (!isset($jobOrderData['public']) || $jobOrderData['public'] == 0)
            {
                // FIXME: Generate valid XHTML error pages. Create an error/fatal method!
                echo '<html><body>This position is no longer available.  Please wait while we direct you to the job list...<script>setTimeout("document.location.href=\'?m=careers&&p=showAll\';", 1500);</script></body></html>';
                die();
            }

            /* Make JavaScript validation rules. */
            $validator = $this->_makeApplyValidator($template);

            /* Translate required fields into normal fields for replacement. */
            $template['Content'] = str_replace(' req>', '>', $template['Content']);

            /* Get the attachment (friendly) file name is there is an attachment uploaded */
            if ($resumeFileLocation != '')
            {
                $resumeFileLocationEscaped = htmlspecialchars((string) $resumeFileLocation, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                $attachmentHTML = '<div style="height: 20px; background-color: #e0e0e0; margin: 5px 0 0px 0; '
                    . 'padding: 0 3px 0 5px; font-size: 11px;"> '
                    . '<img src="images/parser/attachment.gif" border="0" style="padding-top: 3px;" /> '
                    . 'Attachment: <span style="font-weight: bold;">'.$resumeFileLocationEscaped.'</span> '
                    . '</div> ';
            }
            else
            {
                $attachmentHTML = '';
            }

            /* Replace input fields. */
            $jobIdEscaped = htmlspecialchars((string) $jobID, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $template['Content'] = str_replace('<jobid>', $jobIdEscaped, $template['Content']);
            $firstNameEscaped = htmlspecialchars((string) $firstName, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $lastNameEscaped = htmlspecialchars((string) $lastName, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $addressEscaped = htmlspecialchars((string) $address, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $address2Escaped = htmlspecialchars((string) $address2, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $cityEscaped = htmlspecialchars((string) $city, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $stateEscaped = htmlspecialchars((string) $state, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $zipEscaped = htmlspecialchars((string) $zip, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $phoneEscaped = htmlspecialchars((string) $phone, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $emailEscaped = htmlspecialchars((string) $email, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $phoneHomeEscaped = htmlspecialchars((string) $phoneHome, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $phoneCellEscaped = htmlspecialchars((string) $phoneCell, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $bestTimeToCallEscaped = htmlspecialchars((string) $bestTimeToCall, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $email2Escaped = htmlspecialchars((string) $email2, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $emailconfirmEscaped = htmlspecialchars((string) $emailconfirm, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $keySkillsEscaped = htmlspecialchars((string) $keySkills, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $sourceEscaped = htmlspecialchars((string) $source, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $employerEscaped = htmlspecialchars((string) $employer, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $resumeFileLocationEscaped = htmlspecialchars((string) $resumeFileLocation, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $resumeContentsEscaped = htmlspecialchars((string) $resumeContents, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $extraNotesEscaped = htmlspecialchars((string) (isset($_POST[$id='extraNotes']) ? $_POST[$id] : ''), ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobTitleEscaped = htmlspecialchars((string) $jobOrderData['title'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $template['Content'] = str_replace('<title>', $jobTitleEscaped, $template['Content']);
            $template['Content'] = str_replace('<input-firstName>', '<input name="firstName" id="firstName" class="inputBoxName' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $firstNameEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-lastName>', '<input name="lastName" id="lastName" class="inputBoxName' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $lastNameEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-address>', '<input name="address" id="address" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $addressEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-address2>', '<input name="address2" id="address2" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $address2Escaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-city>', '<input name="city" id="city" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $cityEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-state>', '<input name="state" id="state" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $stateEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-zip>', '<input name="zip" id="zip" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $zipEscaped . '" />', $template['Content']);
            $countrySelectHTML = TemplateUtility::getCountrySelectHTML(
                'country',
                (string) $country,
                true,
                ($this->_bootstrapPortal ? 'form-select' : 'inputBoxNormal'),
                ''
            );
            $template['Content'] = str_replace('<input-country>', $countrySelectHTML, $template['Content']);
            $template['Content'] = str_replace('<input-country req>', $countrySelectHTML, $template['Content']);
            $template['Content'] = str_replace('<input-phone>', '<input name="phone" id="phone" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $phoneEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-email>', '<input name="email" id="email" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $emailEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-phone-home>', '<input name="phoneHome" id="phoneHome" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $phoneHomeEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-phone-cell>', '<input name="phoneCell" id="phoneCell" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $phoneCellEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-best-time-to-call>', '<input name="bestTimeToCall" id="bestTimeToCall" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $bestTimeToCallEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-email2>', '<input name="email2" id="email2" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $email2Escaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-emailconfirm>', '<input name="emailconfirm" id="emailconfirm" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $emailconfirmEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-keySkills>', '<input name="keySkills" id="keySkills" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $keySkillsEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-source>', '<input name="source" id="source" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $sourceEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-employer>', '<input name="employer" id="employer" class="inputBoxNormal' . ($this->_bootstrapPortal ? ' form-control' : '') . '" value="' . $employerEscaped . '" />', $template['Content']);
            $template['Content'] = str_replace(array('<input-captcha>', '<input-captcha req>'), $this->getCareerPortalCaptchaInput(), $template['Content']);
            $template['Content'] = str_replace('<input-resumeUpload>', '<input type="file" id="resume" name="file" class="inputBoxFile' . ($this->_bootstrapPortal ? ' form-control' : '') . '" />', $template['Content']);
            $template['Content'] = str_replace('<input-resumeUploadPreview>',
                '<input type="hidden" id="applyToJobSubAction" name="applyToJobSubAction" value="" /> '
                . '<input type="hidden" id="file" name="file" value="' . $resumeFileLocationEscaped . '" /> '
                . ($this->_bootstrapPortal ? '<label for="resumeFile" class="form-label">Upload resume</label>' : '')
                . '<input type="file" id="resumeFile" name="resumeFile" class="inputBoxFile' . ($this->_bootstrapPortal ? ' form-control' : '') . '" size="30" onchange="resumeLoadCheck();" /> '
                . '<input type="button"' . ($this->_bootstrapPortal ? ' class="btn btn-outline-secondary mt-2"' : '') . ' id="resumeLoad" name="resumeLoad" value="Upload" onclick="resumeLoadFile();" disabled />' . ($this->_bootstrapPortal ? '' : '<br /> ')
                . $attachmentHTML
                . ($this->_bootstrapPortal ? '<label for="resumeContents" class="form-label d-block mt-3">Resume text</label>' : '')
                . '<textarea id="resumeContents" name="resumeContents" class="inputBoxArea' . ($this->_bootstrapPortal ? ' form-control' : '') . '" onmousemove="resumeContentsChange(this);" '
                . 'onchange="resumeContentsChange(this);" onmousedown="resumeContentsChange(this);" '
                . ($this->_bootstrapPortal ? '' : 'style="width: 410px; height: 150px;"') . '>' . $resumeContentsEscaped . '</textarea>' . ($this->_bootstrapPortal ? '' : '<br /> ')
                . (
                ($this->_bootstrapPortal ? '<div class="text-end mt-3">' : '<br /><div style="text-align: right;">')
                . '<input type="button"' . ($this->_bootstrapPortal ? ' class="btn btn-outline-secondary"' : '') . ' value="Populate Fields ->" id="resumePopulate" onclick="resumeParse();" '.(strlen($resumeContents)?'':'disabled').' />'
                . ($this->_bootstrapPortal ? '</div>' : '')
                ),
                $template['Content']);
            $template['Content'] = str_replace('<input-extraNotes>', '<textarea name="extraNotes" id="extraNotes" class="inputBoxArea' . ($this->_bootstrapPortal ? ' form-control' : '') . '" maxlength="450" onkeyup="mlength=this.getAttribute ? parseInt(this.getAttribute(\'maxlength\')) : \'\'; if (this.getAttribute && this.value.length>(mlength+7)) { alert(\'Sorry, you may only enter \'+mlength+\' characters into the extra notes.\');} if (this.getAttribute && this.value.length>mlength) {this.value=this.value.substring(0,mlength); this.scrollTop = this.scrollHeight;}">'.$extraNotesEscaped.'</textarea>', $template['Content']);
            $template['Content'] = str_replace('<submit', '<input type="submit" class="submitButton' . ($this->_bootstrapPortal ? ' btn btn-primary' : '') . '"', $template['Content']);

            /* EEO inputs. */
            $template['Content'] = str_replace('<input-eeo-race>', '<select name="eeorace" id="eeorace" class="inputBoxNormal" />
                                                                        <option value="">----</option>
                                                                        <option value="1">American Indian</option>
                                                                        <option value="2">Asian or Pacific Islander</option>
                                                                        <option value="3">Hispanic or Latino</option>
                                                                        <option value="4">Non-Hispanic Black</option>
                                                                        <option value="5">Non-Hispanic White</option>
                                                                    </select>', $template['Content']);

            $template['Content'] = str_replace('<input-eeo-gender>', '<select name="eeogender" id="eeogender" class="inputBoxNormal" />
                                                                        <option value="">----</option>
                                                                        <option value="m">Male</option>
                                                                        <option value="f">Female</option>
                                                                    </select>', $template['Content']);

            $template['Content'] = str_replace('<input-eeo-veteran>', '<select name="eeoveteran" id="eeoveteran" class="inputBoxNormal" />
                                                                        <option value="">----</option>
                                                                        <option value="1">Male</option>
                                                                        <option value="2">Eligible Veteran</option>
                                                                        <option value="3">Disabled Veteran</option>
                                                                        <option value="4">Eligible and Disabled</option>
                                                                    </select>', $template['Content']);

            $template['Content'] = str_replace('<input-eeo-disability>', '<select name="eeodisability" id="eeodisability" class="inputBoxNormal" />
                                                                        <option value="">----</option>
                                                                        <option value="No">No</option>
                                                                        <option value="Yes">Yes</option>
                                                                    </select>', $template['Content']);

            /* Extra field inputs. */
            $candidates = new Candidates();
            $extraFieldsForCandidates = $candidates->extraFields->getValuesForAdd();

            foreach($extraFieldsForCandidates as $ef)
            {
                if (isset($ef['careersAddHTML']))
                {
                    $template['Content'] = str_replace('<input-extraField-' .urlencode($ef['fieldName']) . '>', $ef['careersAddHTML'], $template['Content']);
                }
                else
                {
                    $template['Content'] = str_replace('<input-extraField-' .urlencode($ef['fieldName']) . '>', $ef['addHTML'], $template['Content']);
                }
            }

            /* This is kindof a hack, but basically, we have to put the
             * validation code / form below inside the <td>, which is contained
             * in the template, as they aren't allowed in <tr>s.
             * NOTE: Continue to use ungreedy matching or this will break!
             */
            if (preg_match('/^.*?(<td.*?>)/i', $template['Content'], $matches))
            {
                $startTD = $matches[1];
                $template['Content'] = preg_replace('/^.*?(?:<td.*?>)/i', '', $template['Content']);
            }
            else
            {
                $startTD = '';
            }

            if (preg_match('/(<\/td>).*?$/i', $template['Content'], $matches))
            {
                $endTD = $matches[1];
                $template['Content'] = preg_replace('/(?:<\/td>).*?$/i', '', $template['Content']);
            }
            else
            {
                $endTD = '';
            }

            if (strpos($template['Content'], '<catsform>') === false)
            {
                $template['Content'] = $startTD . "\n" . $validator . "\n"
                    . '<form name="applyToJobForm" id="applyToJobForm" action="'
                    . CATSUtility::getIndexName()
                    . '?m=careers&amp;p=onApplyToJobOrder" '
                    . 'enctype="multipart/form-data" method="post" onsubmit="return applyValidate();">'
                    . '<input type="hidden" name="ID" value="' . $jobID . '">'
                    . '<input type="hidden" name="candidateID" value="' . $candidateID . '">'
                    . $template['Content'] . '</form>' . "\n" . $endTD;
            }
            else
            {
                $template['Content'] = $startTD . "\n" . $validator . "\n" .
                    str_replace('<catsform>', '<form name="applyToJobForm" id="applyToJobForm" action="'
                        . CATSUtility::getIndexName()
                        . '?m=careers&amp;p=onApplyToJobOrder" '
                        . 'enctype="multipart/form-data" method="post" onsubmit="return applyValidate();">'
                        . '<input type="hidden" name="ID" value="' . $jobID . '">'
                        . '<input type="hidden" name="candidateID" value="' . $candidateID . '">',
                        $template['Content'])
                    . "\n" . $endTD;
            }
        }
        else if ($p == 'onApplyToJobOrder')
        {
            if (!$this->isRequiredIDValid('ID', $_POST))
            {
                // FIXME: Generate valid XHTML error pages. Create an error/fatal method!
                echo '<html><body>This position is invalid or no longer available. Please wait while we direct you to the job list...<script>setTimeout("document.location.href=\'?m=careers&&p=showAll\';", 1500);</script></body></html>';
                die();
            }

            if ($this->careerPortalTemplateRequiresCaptcha($template['Content - Apply for Position']))
            {
                $captchaValue = isset($_POST['captcha']) ? $_POST['captcha'] : '';
                if (!$this->validateCareerPortalCaptcha($captchaValue))
                {
                    CommonErrors::fatal(COMMONERROR_MISSINGFIELDS, $this, 'Invalid CAPTCHA response. Please try again.');
                    return;
                }
            }

            // Check if this is a returning candidate
            $candidate = $isRegistrationEnabled ? $this->getCareerPortalCandidate() : false;
            $candidateID = $candidate !== false ? $candidate['candidateID'] : false;

            /**
             * Applicant has completed their application, check to see if a questionnaire
             * is tied to this job order. If so, present it.
             */
            $jobID = intval($_POST['ID']);
            $jobOrderData = $jobOrders->get($jobID);
            $questionnaireLib = new Questionnaire();

            $questionnaireID = $jobOrderData['questionnaireID'];
            if ($questionnaireID)
            {
                $questionnaire = $questionnaireLib->get($questionnaireID);
                if (!is_array($questionnaire) || empty($questionnaire))
                {
                    $questionnaireID = false;
                }
            }

            // Check for postback (if the applicant has completed the questionnaire) or if no questionnaire exists
            if ((isset($_GET[$id='questionnairePostBack']) && $_GET[$id] == '1') || !$questionnaireID)
            {
                // Continue on our merry way
                $this->onApplyToJobOrder($candidateID);

                $jobOrderData = $jobOrders->get($jobID);
                if (!isset($jobOrderData['public']) || $jobOrderData['public'] == 0)
                {
                    // FIXME: Generate valid XHTML error pages. Create an error/fatal method!
                    echo '<html><body>This position is no longer available.  Please wait while we direct you to the job list...<script>setTimeout("document.location.href=\'?m=careers&&p=showAll\';", 1500);</script></body></html>';
                    die();
                }

                $template['Content'] = $template['Content - Thanks for your Submission'];
                $jobTitleEscaped = htmlspecialchars((string) $jobOrderData['title'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                $jobDetailsUrl = CATSUtility::getIndexName() . '?m=careers'
                    . (isset($_GET['templateName']) ? '&templateName=' . urlencode($_GET['templateName']) : '')
                    . '&p=showJob&ID=' . (string) $_POST['ID'];
                $jobDetailsUrl = (string) $jobDetailsUrl;
                if (preg_match('/^\s*javascript:/i', $jobDetailsUrl))
                {
                    $jobDetailsUrl = '';
                }
                else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $jobDetailsUrl) && !preg_match('/^\s*https?:/i', $jobDetailsUrl))
                {
                    $jobDetailsUrl = '';
                }
                $jobDetailsUrlEscaped = htmlspecialchars($jobDetailsUrl, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                $template['Content'] = str_replace('<title>', $jobTitleEscaped, $template['Content']);
                $template['Content'] = str_replace('<a-jobDetails>', '<a href="' . $jobDetailsUrlEscaped . '">', $template['Content']);
            }
            else
            {
                ob_start();

                // get questions/answers
                $questions = $questionnaireLib->getQuestions($questionnaireID);

                $this->_template->assign('isModal', true);
                $this->_template->assign('questionnaireID', $questionnaireID);
                $this->_template->assign('data', $questionnaire);
                $this->_template->assign('questions', $questions);
                $this->_template->display($this->_bootstrapPortal
                    ? './modules/careers/Questionnaire.tpl'
                    : './modules/settings/CareerPortalQuestionnaireShow.tpl');

                $buffer = ob_get_contents();
                ob_end_clean();

                $formData = '<form name="postQuestionnaire" id="postQuestionnaire" '
                    . 'enctype="multipart/form-data" method="post" action="'
                    . CATSUtility::getIndexName() . '?m=careers&p=onApplyToJobOrder'
                    . '&questionnairePostBack=1">' . "\n"
                    . $this->capturePostData();

                // Collect all of the post data and resubmit it as hidden elements
                $buffer = $formData . $buffer;

                $template['Content'] = str_replace('<questionnaire>', $buffer, $template['Content - Questionnaire']);
                $template['Content'] = str_replace('<submit', '<input type="submit" class="submitButton' . ($this->_bootstrapPortal ? ' btn btn-primary' : '') . '"', $template['Content']) . '</form>';
            }
        }
        else if ($p == 'showJob')
        {
            $template['Content'] = $template['Content - Job Details'];

            $jobID = $_GET['ID'];

            /* Filter out non numeric characters */
            for ($i = 0; $i < strlen($jobID); $i++)
            {
                if (ord(substr($jobID, $i, 1)) < ord('0') || ord(substr($jobID, $i, 1)) > ord('9') )
                {
                    $jobID = str_replace(substr($jobID, $i, 1), '*', $jobID);
                }
            }
            $jobID = str_replace('*', '', $jobID);

            /* Force integer */
            $jobID = $jobID * 1;

            $jobOrderData = $jobOrders->get($jobID);
            if (!isset($jobOrderData['public']) || $jobOrderData['public'] == 0)
            {
                echo '<html><body>This position is no longer available.  Please wait while we direct you to the job list...<script>setTimeout("document.location.href=\'?m=careers&&p=showAll\';", 1500);</script></body></html>';
                die ();
            }

            $jobTitleEscaped = htmlspecialchars((string) $jobOrderData['title'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobOpeningsEscaped = htmlspecialchars((string) $jobOrderData['openings'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobTypeEscaped = htmlspecialchars((string) $jobOrders->typeCodeToString($jobOrderData['type']), ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobCreatedEscaped = htmlspecialchars((string) $jobOrderData['dateCreated'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobRecruiterEscaped = htmlspecialchars((string) $jobOrderData['recruiterFullName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobCompanyNameEscaped = htmlspecialchars((string) $jobOrderData['companyName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobContactNameEscaped = htmlspecialchars((string) $jobOrderData['contactFullName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobContactPhoneEscaped = htmlspecialchars((string) $jobOrderData['contactWorkPhone'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobContactEmailEscaped = htmlspecialchars((string) $jobOrderData['contactEmail'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $jobRateEscaped = nl2br(htmlspecialchars((string) $jobOrderData['maxRate'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING));
            $jobSalaryEscaped = nl2br(htmlspecialchars((string) $jobOrderData['salary'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING));
            $jobDaysOldEscaped = nl2br(htmlspecialchars((string) $jobOrderData['daysOld'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING));
            $jobLocationEscaped = htmlspecialchars(
                $this->getLocationString(
                    $jobOrderData['city'],
                    $jobOrderData['state'],
                    $jobOrderData['country']
                ),
                ENT_QUOTES | ENT_SUBSTITUTE,
                HTML_ENCODING
            );
            $template['Content'] = str_replace('<registeredCandidate>', $isRegistrationEnabled ? $this->getRegisteredCandidateBlock($template['Content - Candidate Registration']) : '', $template['Content']);
            $template['Content'] = str_replace('<title>',        $jobTitleEscaped, $template['Content']);
            $template['Content'] = str_replace('<location>',     $jobLocationEscaped, $template['Content']);
            $template['Content'] = str_replace('<openings>',     $jobOpeningsEscaped, $template['Content']);
            $template['Content'] = str_replace('<type>',         $jobTypeEscaped, $template['Content']);
            $template['Content'] = str_replace('<created>',      $jobCreatedEscaped, $template['Content']);
            $template['Content'] = str_replace('<recruiter>',    $jobRecruiterEscaped, $template['Content']);
            $template['Content'] = str_replace('<companyName>',  $jobCompanyNameEscaped, $template['Content']);
            $template['Content'] = str_replace('<contactName>',  $jobContactNameEscaped, $template['Content']);
            $template['Content'] = str_replace('<contactPhone>', $jobContactPhoneEscaped, $template['Content']);
            $template['Content'] = str_replace('<contactEmail>', $jobContactEmailEscaped, $template['Content']);
            $template['Content'] = str_replace('<description>',  (string) $jobOrderData['description'], $template['Content']);
            $template['Content'] = str_replace('<rate>',         $jobRateEscaped, $template['Content']);
            $template['Content'] = str_replace('<salary>',       $jobSalaryEscaped, $template['Content']);
            $template['Content'] = str_replace('<daysOld>',      $jobDaysOldEscaped, $template['Content']);

            $isRegistered = $isRegistrationEnabled && $this->getCareerPortalCandidate() !== false;

            // If candidate registration is enabled, ask them if they would like to log in first
            if ($isRegistrationEnabled && !$isRegistered)
            {
                $applyToJobUrl = CATSUtility::getIndexName() . '?m=careers'
                    . (isset($_GET['templateName']) ? '&templateName=' . urlencode($_GET['templateName']) : '')
                    . '&p=candidateRegistration&ID=' . (string) $jobID;
                $applyToJobUrl = (string) $applyToJobUrl;
                if (preg_match('/^\s*javascript:/i', $applyToJobUrl))
                {
                    $applyToJobUrl = '';
                }
                else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $applyToJobUrl) && !preg_match('/^\s*https?:/i', $applyToJobUrl))
                {
                    $applyToJobUrl = '';
                }
                $applyToJobUrlEscaped = htmlspecialchars($applyToJobUrl, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                $template['Content'] = str_replace('<a-applyToJob', '<a href="' . $applyToJobUrlEscaped . '"', $template['Content']);
            }
            else
            {
                $applyToJobUrl = CATSUtility::getIndexName() . '?m=careers'
                    . (isset($_GET['templateName']) ? '&templateName=' . urlencode($_GET['templateName']) : '')
                    . '&p=applyToJob&ID=' . (string) $jobID;
                $applyToJobUrl = (string) $applyToJobUrl;
                if (preg_match('/^\s*javascript:/i', $applyToJobUrl))
                {
                    $applyToJobUrl = '';
                }
                else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $applyToJobUrl) && !preg_match('/^\s*https?:/i', $applyToJobUrl))
                {
                    $applyToJobUrl = '';
                }
                $applyToJobUrlEscaped = htmlspecialchars($applyToJobUrl, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                $template['Content'] = str_replace('<a-applyToJob', '<a href="' . $applyToJobUrlEscaped . '"', $template['Content']);
            }

            $jobOrders = new JobOrders();
            $extraFieldsForJobOrders = $jobOrders->extraFields->getValuesForShow($jobID);

            foreach($extraFieldsForJobOrders as $ef)
            {
                $template['Content'] = str_replace('<extraField-' .urlencode($ef['fieldName']) . '>', htmlspecialchars((string) $ef['display'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING), $template['Content']);
            }
        }
        else if ($p == 'searchResults')
        {
        }
        else
        {
            $template['Content'] = $template['Content - Main'];
            $template['Content'] = str_replace('<registeredCandidate>', $isRegistrationEnabled ? $this->getRegisteredCandidateBlock($template['Content - Candidate Registration']) : '', $template['Content']);

            $template['Content'] = str_replace('<registeredLoginTitle>', '<div style="display: none;">', $template['Content']);
            $template['Content'] = str_replace('</registeredLoginTitle>', '</div>', $template['Content']);
            $template['Content'] = str_replace(
                '<registeredLogin>',
                $isRegistrationEnabled && $this->getCareerPortalCandidate() === false
                ? '<p>To sign in, select a current vacancy and choose to apply as a returning candidate.</p>'
                : '',
                $template['Content']
            );

        }

        $indexName = CATSUtility::getIndexName();
        foreach ($template as $index => $data)
        {
            $linkMainUrl = $indexName . '?m=careers' . (isset($_GET['templateName']) ? '&templateName=' . urlencode($_GET['templateName']) : '');
            $linkMainUrl = (string) $linkMainUrl;
            if (preg_match('/^\s*javascript:/i', $linkMainUrl))
            {
                $linkMainUrl = '';
            }
            else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $linkMainUrl) && !preg_match('/^\s*https?:/i', $linkMainUrl))
            {
                $linkMainUrl = '';
            }
            $linkMainUrlEscaped = htmlspecialchars($linkMainUrl, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $linkSearchUrl = $indexName . '?m=careers' . (isset($_GET['templateName']) ? '&templateName=' . urlencode($_GET['templateName']) : '') . '&p=search';
            $linkSearchUrl = (string) $linkSearchUrl;
            if (preg_match('/^\s*javascript:/i', $linkSearchUrl))
            {
                $linkSearchUrl = '';
            }
            else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $linkSearchUrl) && !preg_match('/^\s*https?:/i', $linkSearchUrl))
            {
                $linkSearchUrl = '';
            }
            $linkSearchUrlEscaped = htmlspecialchars($linkSearchUrl, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $linkListAllUrl = $indexName . '?m=careers' . (isset($_GET['templateName']) ? '&templateName=' . urlencode($_GET['templateName']) : '') . '&p=showAll';
            $linkListAllUrl = (string) $linkListAllUrl;
            if (preg_match('/^\s*javascript:/i', $linkListAllUrl))
            {
                $linkListAllUrl = '';
            }
            else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $linkListAllUrl) && !preg_match('/^\s*https?:/i', $linkListAllUrl))
            {
                $linkListAllUrl = '';
            }
            $linkListAllUrlEscaped = htmlspecialchars($linkListAllUrl, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $template[$index] = str_replace('<a-LinkMain>',   '<a href="' . $linkMainUrlEscaped . '">', $template[$index]);
            $template[$index] = str_replace('<a-LinkSearch>', '<a href="' . $linkSearchUrlEscaped . '">', $template[$index]);
            $template[$index] = str_replace('<a-ListAll>',    '<a href="' . $linkListAllUrlEscaped . '">', $template[$index]);
            $template[$index] = str_replace('<siteName>', $siteNameEscaped, $template[$index]);
            $numberOfOpenPositionsEscaped = htmlspecialchars((string) count($rs), ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $template[$index] = str_replace('<numberOfOpenPositions>', $numberOfOpenPositionsEscaped, $template[$index]);

            /* Hacks for loading from a nonstandard root directory. */
            if (isset($careerPage) && $careerPage == true)
            {
                $template[$index] = str_replace('"images/', '"../images/', $template[$index]);
                $template[$index] = str_replace('\'images/', '\'../images/', $template[$index]);
                $template[$index] = str_replace('<rssURL>', '../rss/', $template[$index]);
            }
            else
            {
                $template[$index] = str_replace('<rssURL>', 'rss/', $template[$index]);
            }
        }

        $this->_template->assign('template', $template);
        $this->_template->assign('siteName', $siteName);

        if (!eval(Hooks::get('CAREERS_PAGE_BOTTOM'))) return;

        if ($careerPortalSettingsRS['useCATSTemplate'] != '')
        {
            $this->_template->display($careerPortalSettingsRS['useCATSTemplate']);
        }
        else
        {
            $this->_template->display($this->_bootstrapPortal
                ? './modules/careers/Bootstrap.tpl' : './modules/careers/Blank.tpl');
        }
    }

    private function getCareerPortalCandidate()
    {
        $candidateID = $_SESSION['careerPortalCandidateID'] ?? null;
        if (!is_int($candidateID) || $candidateID <= 0)
        {
            return false;
        }

        $candidates = new Candidates();
        $candidate = $candidates->get($candidateID);
        if (empty($candidate['candidateID']))
        {
            unset($_SESSION['careerPortalCandidateID']);
            return false;
        }
        return $candidate;
    }

    private function candidateLogin($template, $jobOrders, $publicJobOrders)
    {
        $jobID = $_GET['ID'] ?? null;
        if ((!is_string($jobID) && !is_int($jobID)) || filter_var($jobID, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1))) === false)
        {
            return false;
        }
        $jobID = (int) $jobID;
        $jobOrder = $jobOrders->get($jobID);
        // Reuse the exact visibility rules used for the portal's vacancy listing.
        if (empty($jobOrder['public']) || !in_array($jobID, array_column($publicJobOrders, 'jobOrderID')))
        {
            return false;
        }

        // New applicants continue to the existing application form without authentication.
        if (isset($_POST['isNew']) && $_POST['isNew'] === 'yes')
        {
            return true;
        }
        if (!$this->validateCareerPortalCaptcha($_POST['captcha'] ?? ''))
        {
            return false;
        }
        if ($this->getCareerPortalCandidate() !== false)
        {
            return true;
        }
        $candidate = $this->ProcessCandidateRegistration($template);
        if ($candidate === false || empty($candidate['candidateID']))
        {
            return false;
        }

        session_regenerate_id(true);
        $_SESSION['careerPortalCandidateID'] = (int) $candidate['candidateID'];
        return true;
    }

    private function getCareerPortalCaptchaInput()
    {
        return '<img src="' . CATSUtility::getIndexName() . '?m=careers&amp;p=captcha&amp;t=' . time()
        . '" alt="Captcha" /><br /><label for="captcha">Enter the code shown above:</label> '
        . '<input type="text" name="captcha" id="captcha" class="inputBoxNormal'
        . ($this->_bootstrapPortal ? ' form-control' : '') . '" />';
    }

    private function outputCareerPortalCaptcha()
    {
        $builder = new \Gregwar\Captcha\CaptchaBuilder();
        $builder->build();

        $_SESSION['careerPortalCaptcha'] = $builder->getPhrase();

        header('Content-type: image/jpeg');
        $builder->output();

        die();
    }

    private function careerPortalTemplateRequiresCaptcha($templateContent)
    {
        return (strpos($templateContent, '<input-captcha req>') !== false);
    }

    private function validateCareerPortalCaptcha($captchaValue)
    {
        $expectedPhrase = isset($_SESSION['careerPortalCaptcha']) ? trim((string) $_SESSION['careerPortalCaptcha']) : '';
        $submittedPhrase = is_string($captchaValue) ? trim($captchaValue) : '';

        $this->clearCareerPortalCaptchaPhrase();

        if ($expectedPhrase === '' || $submittedPhrase === '')
        {
            return false;
        }

        return (strcasecmp($submittedPhrase, $expectedPhrase) === 0);
    }

    private function clearCareerPortalCaptchaPhrase()
    {
        unset($_SESSION['careerPortalCaptcha']);
    }


    private function _makeApplyValidator($template)
    {
        $validator = '';

        // First name is always required if the field is present in the template.
        if (strpos($template['Content'], '<input-firstName>') !== false || strpos($template['Content'], '<input-firstName req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'firstName\').value == \'\')
                {
                    alert(\'Please enter a first name.\');
                    document.getElementById(\'firstName\').focus();
                    return false;
                }';
        }

        // Last name is always required if the field is present in the template.
        if (strpos($template['Content'], '<input-lastName>') !== false || strpos($template['Content'], '<input-lastName req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'lastName\').value == \'\')
                {
                    alert(\'Please enter a last name.\');
                    document.getElementById(\'lastName\').focus();
                    return false;
                }';
        }

        // Email confirmation must match the primary email if the field is present.
        if (strpos($template['Content'], '<input-emailconfirm>') !== false || strpos($template['Content'], '<input-emailconfirm req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'emailconfirm\').value != document.getElementById(\'email\').value)
                {
                    alert(\'Your E-Mail address doesn\\\'t match the retyped E-Mail address.\');
                    document.getElementById(\'emailconfirm\').focus();
                    return false;
                }';
        }

        // Primary email must be present and must look somewhat valid.
        if (strpos($template['Content'], '<input-email>') !== false || strpos($template['Content'], '<input-email req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'email\').value == \'\')
                {
                    alert(\'Please enter an E-Mail address.\');
                    document.getElementById(\'email\').focus();
                    return false;
                }
                if (document.getElementById(\'email\').value.indexOf(\'@\') == -1 ||
                    document.getElementById(\'email\').value.indexOf(\'.\') == -1)
                {
                    alert(\'Please enter a valid E-Mail address.\');
                    document.getElementById(\'email\').focus();
                    return false;
                }';
        }

        /*
         * Optional fields that can be made required by using the "req" marker
         * in the template, for example <input-phone-cell req>.
         */

        if (strpos($template['Content'], '<input-address req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'address\').value == \'\')
                {
                    alert(\'Please enter an address.\');
                    document.getElementById(\'address\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-address2 req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'address2\').value == \'\')
                {
                    alert(\'Please enter address line 2.\');
                    document.getElementById(\'address2\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-city req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'city\').value == \'\')
                {
                    alert(\'Please enter a city.\');
                    document.getElementById(\'city\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-state req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'state\').value == \'\')
                {
                    alert(\'Please enter a state.\');
                    document.getElementById(\'state\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-zip req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'zip\').value == \'\')
                {
                    alert(\'Please enter a zip code.\');
                    document.getElementById(\'zip\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-country req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'country\').value == \'\')
                {
                    alert(\'Please select a country.\');
                    document.getElementById(\'country\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-phone req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'phone\').value == \'\')
                {
                    alert(\'Please enter a phone number.\');
                    document.getElementById(\'phone\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-phone-cell req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'phoneCell\').value == \'\')
                {
                    alert(\'Please enter a mobile phone number.\');
                    document.getElementById(\'phoneCell\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-phone-home req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'phoneHome\').value == \'\')
                {
                    alert(\'Please enter a home phone number.\');
                    document.getElementById(\'phoneHome\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-best-time-to-call req>') !== false ||
            strpos($template['Content'], '<input-bestTimeToCall req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'bestTimeToCall\').value == \'\')
                {
                    alert(\'Please enter the best time to call.\');
                    document.getElementById(\'bestTimeToCall\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-email2 req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'email2\').value == \'\')
                {
                    alert(\'Please enter an E-Mail address.\');
                    document.getElementById(\'email2\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-source req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'source\').value == \'\')
                {
                    alert(\'Please enter a source.\');
                    document.getElementById(\'source\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-employer req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'employer\').value == \'\')
                {
                    alert(\'Please enter your current employer.\');
                    document.getElementById(\'employer\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-resumeUpload req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'resume\').value == \'\')
                {
                    alert(\'Please upload your resume.\');
                    document.getElementById(\'resume\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-keySkills req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'keySkills\').value == \'\')
                {
                    alert(\'Please enter some key skills.\');
                    document.getElementById(\'keySkills\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-extraNotes req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'extraNotes\').value == \'\')
                {
                    alert(\'Please enter some extra notes.\');
                    document.getElementById(\'extraNotes\').focus();
                    return false;
                }';
        }

        /*
         * EEO fields (if enabled and placed in the template).
         */

        if (strpos($template['Content'], '<input-eeo-gender req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'eeogender\').value == \'\')
                {
                    alert(\'Please select your gender.\');
                    document.getElementById(\'eeogender\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-eeo-race req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'eeorace\').value == \'\')
                {
                    alert(\'Please select your race.\');
                    document.getElementById(\'eeorace\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-eeo-veteran req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'eeoveteran\').value == \'\')
                {
                    alert(\'Please select your veteran status.\');
                    document.getElementById(\'eeoveteran\').focus();
                    return false;
                }';
        }

        if (strpos($template['Content'], '<input-eeo-disability req>') !== false)
        {
            $validator .= '
                if (document.getElementById(\'eeodisability\').value == \'\')
                {
                    alert(\'Please select your disability status.\');
                    document.getElementById(\'eeodisability\').focus();
                    return false;
                }';
        }

        $validator = '<script type="text/javascript">function applyValidate() {'
            . $validator . ' return true; }' . "\n" . '</script>';

        return $validator;
    }

    /*
     * Gets HTML content for the job order response array.
     */
    // FIXME: More of this needs to be done in the template. The UI shouldn't generate HTML.
    private function getResultsTable($rs, $settings, $unformatted = false, $parameters = '')
    {
        if ($unformatted)
        {
            $html  = '<table class="sortable">' . "\n";
        }
        else
        {
            $html  = '<table class="sortable" style="width:100%;">' . "\n";
        }
        if ($this->_bootstrapPortal)
        {
            $html = '<table class="sortable table table-striped align-middle">' . "\n";
        }
        $html .= '<tr class="rowHeading" align="left">'."\n";
        if ($settings['showCompany'] == 1)
        {
            $html .= '<th nowrap="nowrap">Company</th>';
        }
        if ($settings['showDepartment'] == 1)
        {
            $html .= '<th nowrap="nowrap" align="left">Department</th>';
        }
        $html .= '<th nowrap="nowrap" align="left">Position Title</th>';
        $html .= '<th nowrap="nowrap" align="left">Location</th>';
        $html .= '</tr>'."\n";

        $rowIsEven = false;
        foreach ($rs as $index => $line)
        {
            $rowIsEven = !$rowIsEven;
            if ($rowIsEven)
            {
                $html .= '<tr class="evenTableRow">'."\n";
            }
            else
            {
                $html .= '<tr class="oddTableRow">'."\n";
            }

            if ($settings['showCompany'] == 1)
            {
                $html .= '<td>';
                $html .= htmlspecialchars((string) $line['companyName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                $html .= '</td>';
            }

            if ($settings['showDepartment'] == 1)
            {
                $html .= '<td>';
                if ($line['departmentID'] == 0)
                {
                    $html .= 'General';
                }
                else
                {
                    $html .= htmlspecialchars((string) $line['departmentName'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
                }
                $html .= '</td>';
            }

            $html .= '<td>';
            $html .= '<a href="' . CATSUtility::getIndexName() . '?m=careers' . (isset($_GET['templateName']) ? '&amp;templateName=' . urlencode($_GET['templateName']) : '').'&amp;p=showJob&amp;ID=' . $line['jobOrderID'] . '">';
            $html .= htmlspecialchars((string) $line['title'], ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $html .= '</a>';
            $html .= '</td>';

            $html .= '<td>';
            $html .= htmlspecialchars($this->getLocationString(
                $line['city'],
                $line['state'],
                $line['country']
            ), ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
            $html .= '</td>';

            $html .= '</tr>'."\n";
        }
        $html .= '</table>';

        return $html;
    }

    private function getLocationString($city, $state, $country)
    {
        $city = (string) $city;
        $state = (string) $state;
        $country = trim((string) $country);

        $location = StringUtility::makeCityStateString($city, $state);

        if ($country == '')
        {
            return $location;
        }

        $countryName = isset($GLOBALS['countries'][$country]) ? $GLOBALS['countries'][$country] : $country;
        if ($location == '')
        {
            return $countryName;
        }

        return $location . ', ' . $countryName;
    }

    /* Called by Careers Page function to handle the processing of candidate input. */
    private function onApplyToJobOrder($candidateID = false)
    {
        $jobOrders = new JobOrders();
        $careerPortalSettings = new CareerPortalSettings();

        if (!$this->isRequiredIDValid('ID', $_POST))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'Invalid job order ID.');
            return;
        }

        $jobOrderID = $_POST['ID'];

        $jobOrderData = $jobOrders->get($jobOrderID);
        if (!isset($jobOrderData['public']) || $jobOrderData['public'] == 0)
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order could not be found.');
            return;
        }
	    
        // NOTE: Careers Portal renders these values into HTML without consistent output escaping.
        // TODO (security/xss-hardening): Escape attributes/textarea/title consistently, then switch to getTrimmedInput().
        $lastName       = $this->getSanitisedInput('lastName', $_POST);
        $middleName     = $this->getSanitisedInput('middleName', $_POST);
        $firstName      = $this->getSanitisedInput('firstName', $_POST);
        $email          = $this->getSanitisedInput('email', $_POST);
        $email2         = $this->getSanitisedInput('email2', $_POST);
        $address        = $this->getSanitisedInput('address', $_POST);
        $address2       = $this->getSanitisedInput('address2', $_POST);
        $city           = $this->getSanitisedInput('city', $_POST);
        $state          = $this->getSanitisedInput('state', $_POST);
        $zip            = $this->getSanitisedInput('zip', $_POST);
        $country        = false;
        if (isset($_POST['country']))
        {
            $country = strtoupper($this->getTrimmedInput('country', $_POST));
            if ($country != '' && !isset($GLOBALS['countries'][$country]))
            {
                $country = '';
            }
        }
        $source         = $this->getSanitisedInput('source', $_POST);
        $phone          = $this->getSanitisedInput('phone', $_POST);
        $phoneHome      = $this->getSanitisedInput('phoneHome', $_POST);
        $phoneCell      = $this->getSanitisedInput('phoneCell', $_POST);
        $bestTimeToCall = $this->getSanitisedInput('bestTimeToCall', $_POST);
        $keySkills      = $this->getSanitisedInput('keySkills', $_POST);
        $extraNotes     = $this->getSanitisedInput('extraNotes', $_POST);
        $employer       = $this->getSanitisedInput('employer', $_POST);

        $gender         = $this->getSanitisedInput('eeogender', $_POST);
        $race           = $this->getSanitisedInput('eeorace', $_POST);
        $veteran        = $this->getSanitisedInput('eeoveteran', $_POST);
        $disability     = $this->getSanitisedInput('eeodisability', $_POST);

        if (empty($firstName))
        {
            CommonErrors::fatal(COMMONERROR_MISSINGFIELDS, $this, 'First Name is a required field - please have your administrator edit your templates to include the first name field.');
        }

        if (empty($lastName))
        {
            CommonErrors::fatal(COMMONERROR_MISSINGFIELDS, $this, 'Last Name is a required field - please have your administrator edit your templates to include the last name field.');
        }

        if (empty($email))
        {
            CommonErrors::fatal(COMMONERROR_MISSINGFIELDS, $this, 'E-Mail address is a required field - please have your administrator edit your templates to include the email field.');
        }

        if (empty($source))
        {
            $source = 'Online Careers Website';
        }

        $users = new Users();
        $automatedUser = $users->getAutomatedUser();

        /* Find if another user with same e-mail exists. If so, update the user
         * to contain the new information.
         */
        $candidates = new Candidates();

        if ($candidateID !== false)
        {
            $candidate = $candidates->get($candidateID);

            // Candidate exists and registered. Update their profile with new values (if provided)
            $candidates->update(
                $candidateID, $candidate['isActive'] ? true : false, $firstName, $middleName,
                $lastName, $email, $email2, $phoneHome, $phoneCell, $phone, $address, $address2, $city,
                $state, $zip, $source, $keySkills, '', $employer, '', '', '', $candidate['notes'],
                '', $bestTimeToCall, $automatedUser['userID'], false,
                '', '', $gender, $race, $veteran, $disability, $country
            );

            /* Update extra feilds */
            $candidates->extraFields->setValuesOnEdit($candidateID);
        }
        else
        {
            // Lookup the candidate by e-mail, use that candidate instead if found (but don't update profile)
            $candidateID = $candidates->getIDByEmail($email);
        }

        if ($candidateID === false || $candidateID < 0)
        {
            /* New candidate. */
            $candidateID = $candidates->add(
                $firstName,
                $middleName,
                $lastName,
                $email,
                $email2,
                $phoneHome,
                $phoneCell,
                $phone,
                $address,
                $address2,
                $city,
                $state,
                $zip,
                $source,
                $keySkills,
                '',
                $employer,
                '',
                '',
                '',
                'Candidate submitted these notes with first application: '
                . "\n\n" . $extraNotes,
                '',
                $bestTimeToCall,
                $automatedUser['userID'],
                $automatedUser['userID'],
                $gender,
                $race,
                $veteran,
                $disability,
                false,
                $country === false ? '' : $country
            );

            /* Update extra fields. */
            $candidates->extraFields->setValuesOnEdit($candidateID);
        }

        // If the candidate was added and a questionnaire exists for the job order
        if ($candidateID > 0 && ($questionnaireID = $jobOrderData['questionnaireID']))
        {
            $questionnaireLib = new Questionnaire();
            // Perform any actions specified by the questionnaire
            $questionnaireLib->doActions($questionnaireID, $candidateID, $_POST);
        }

        $fileUploaded = false;

        /* Upload resume (no questionnaire) */
        if (isset($_FILES['file']) && !empty($_FILES['file']['name']))
        {
            $attachmentCreator = new AttachmentCreator();
            $attachmentCreator->createFromUpload(
                DATA_ITEM_CANDIDATE, $candidateID, 'file', false, true
            );

            if ($attachmentCreator->isError())
            {
                CommonErrors::fatal(COMMONERROR_FILEERROR, $this, $attachmentCreator->getError());
                return;
            }

            $duplicatesOccurred = $attachmentCreator->duplicatesOccurred();

            $isTextExtractionError = $attachmentCreator->isTextExtractionError();
            $textExtractionErrorMessage = $attachmentCreator->getTextExtractionError();

            // FIXME: Show parse errors!

            $fileUploaded = true;
            $resumePath = $attachmentCreator->getNewFilePath();
        }
        /* Upload resume (with questionnaire) */
        else if (isset($_POST['file']) && !empty($_POST['file']))
        {
            $resumePath = '';

            $newFilePath = FileUtility::getUploadFilePath('careerportaladd', $_POST['file']);

            if ($newFilePath !== false)
            {
                $attachmentCreator = new AttachmentCreator();
                $attachmentCreator->createFromFile(
                    DATA_ITEM_CANDIDATE, $candidateID, $newFilePath, false, '', true, true
                );

                if ($attachmentCreator->isError())
                {
                    CommonErrors::fatal(COMMONERROR_FILEERROR, $this, $attachmentCreator->getError());
                    return;
                }

                $duplicatesOccurred = $attachmentCreator->duplicatesOccurred();

                $isTextExtractionError = $attachmentCreator->isTextExtractionError();
                $textExtractionErrorMessage = $attachmentCreator->getTextExtractionError();

                // FIXME: Show parse errors!

                $fileUploaded = true;
                $resumePath = $attachmentCreator->getNewFilePath();
            }
        }

        $pipelines = new Pipelines();
        $activityEntries = new ActivityEntries();

        /* Is the candidate already in the pipeline for this job order? */
        $rs = $pipelines->get($candidateID, $jobOrderID);
        if (count($rs) == 0)
        {
            /* Attempt to add the candidate to the pipeline. */
            if (!$pipelines->add($candidateID, $jobOrderID))
            {
                CommonErrors::fatal(COMMONERROR_RECORDERROR, $this, 'Failed to add candidate to job order.');
            }

            // FIXME: For some reason, pipeline entries like to disappear between
            //        the above add() and this get(). WTF?
            $rs = $pipelines->get($candidateID, $jobOrderID);
            if (isset($rs['candidateJobOrderID']))
                $pipelines->updateRatingValue($rs['candidateJobOrderID'], -1);

            $newApplication = true;
        }
        else
        {
            $newApplication = false;
        }

        /* Build activity note. */
        if (!$newApplication)
        {
            $activityNote = 'User re-applied through candidate portal';
        }
        else
        {
            $activityNote = 'User applied through candidate portal';
        }

        if ($fileUploaded)
        {
            if (!$duplicatesOccurred)
            {
                $activityNote .= ' <span style="font-weight: bold;">and'
                    . ' attached a new resume (<a href="' . $resumePath
                    . '">Download</a>)</span>';
            }
            else
            {
                $activityNote .= ' and attached an existing resume (<a href="'
                    . $resumePath . '">Download</a>)';
            }
        }

		if (!empty($extraNotes))
		{
        	$activityNote .= '; added these notes: ' . $extraNotes;
		}

        /* Add the activity note. */
        $activityID = $activityEntries->add(
            $candidateID,
            DATA_ITEM_CANDIDATE,
            ACTIVITY_OTHER,
            $activityNote,
            $automatedUser['userID'],
            $jobOrderID
        );

        /* Send an E-Mail describing what happened. */
        $emailTemplates = new EmailTemplates();
        $candidatesEmailTemplateRS = $emailTemplates->getByTag(
            'EMAIL_TEMPLATE_CANDIDATEAPPLY'
        );

        if (!isset($candidatesEmailTemplateRS['textReplaced']) ||
            empty($candidatesEmailTemplateRS['textReplaced']) ||
            $candidatesEmailTemplateRS['disabled'] == 1)
        {
            $candidatesEmailTemplate = '';
        }
        else
        {
            $candidatesEmailTemplate = $candidatesEmailTemplateRS['textReplaced'];
        }

        /* Replace e-mail template variables. */
        /* E-Mail #1 - to candidate */
        $stringsToFind = array(
            '%CANDFIRSTNAME%',
            '%CANDFULLNAME%',
            '%JBODOWNER%',
            '%JBODTITLE%',
            '%JBODCLIENT%'
        );
        $replacementStrings = array(
            $firstName,
            $firstName . ' ' . $lastName,
            $jobOrderData['ownerFullName'],
            $jobOrderData['title'],
            $jobOrderData['companyName']

            //'<a href="http://' . $_SERVER['HTTP_HOST'] . substr($_SERVER['REQUEST_URI'], 0, strpos($_SERVER['REQUEST_URI'], '?')) . '?m=candidates&amp;a=show&amp;candidateID=' . $candidateID . '">'.
              //  'http://' . $_SERVER['HTTP_HOST'] . substr($_SERVER['REQUEST_URI'], 0, strpos($_SERVER['REQUEST_URI'], '?')) . '?m=candidates&amp;a=show&amp;candidateID=' . $candidateID . '</a>'
        );
        $candidatesEmailTemplate = str_replace(
            $stringsToFind,
            $replacementStrings,
            $candidatesEmailTemplate
        );

        $emailContents = $candidatesEmailTemplate;

        if (!empty($emailContents))
        {
            $careerPortalSettings->sendEmail(
                $automatedUser['userID'],
                $email,
                CAREERS_CANDIDATEAPPLY_SUBJECT,
                $emailContents
            );
        }

        /* E-Mail #2 - to owner */

        $candidatesEmailTemplateRS = $emailTemplates->getByTag(
            'EMAIL_TEMPLATE_CANDIDATEPORTALNEW'
        );

        if (!isset($candidatesEmailTemplateRS['textReplaced']) ||
            empty($candidatesEmailTemplateRS['textReplaced']) ||
            $candidatesEmailTemplateRS['disabled'] == 1)
        {
            $candidatesEmailTemplate = '';
        }
        else
        {
            $candidatesEmailTemplate = $candidatesEmailTemplateRS['textReplaced'];
        }

        // FIXME: This will break if 'http' is elsewhere in the URL.
        $uri = str_replace('employment', '', $_SERVER['REQUEST_URI']);
        $uri = str_replace('http://', 'http', $uri);
        $uri = str_replace('//', '/', $uri);
        $uri = str_replace('http', 'http://', $uri);
        $uri = str_replace('/careers', '', $uri);

        /* Replace e-mail template variables. */
        $stringsToFind = array(
            '%CANDFIRSTNAME%',
            '%CANDFULLNAME%',
            '%JBODOWNER%',
            '%CANDOWNER%',     // Because the candidate was just added, we assume
            '%JBODTITLE%',     // the candidate owner = job order owner.
            '%JBODCLIENT%',
            '%CANDCATSURL%',
            '%JBODID%',
            '%JBODCATSURL%'
        );
        $replacementStrings = array(
            $firstName,
            $firstName . ' ' . $lastName,
            $jobOrderData['ownerFullName'],
            $jobOrderData['ownerFullName'],
            $jobOrderData['title'],
            $jobOrderData['companyName'],
            '<a href="http://' . $_SERVER['HTTP_HOST'] . substr($uri, 0, strpos($uri, '?')) . '?m=candidates&amp;a=show&amp;candidateID=' . $candidateID . '">'.
                'http://' . $_SERVER['HTTP_HOST'] . substr($uri, 0, strpos($uri, '?')) . '?m=candidates&amp;a=show&amp;candidateID=' . $candidateID . '</a>',
            $jobOrderData['jobOrderID'],
            '<a href="http://' . $_SERVER['HTTP_HOST'] . substr($uri, 0, strpos($uri, '?')) . '?m=joborders&amp;a=show&amp;jobOrderID=' . $jobOrderData['jobOrderID'] . '">'.
                'http://' . $_SERVER['HTTP_HOST'] . substr($uri, 0, strpos($uri, '?')) . '?m=joborders&amp;a=show&amp;jobOrderID=' . $jobOrderData['jobOrderID'] . '</a>',
        );
        $candidatesEmailTemplate = str_replace(
            $stringsToFind,
            $replacementStrings,
            $candidatesEmailTemplate
        );

        $emailContents = $candidatesEmailTemplate;

        if (!empty($emailContents))
        {
            $careerPortalSettings->sendEmail(
                $automatedUser['userID'],
                $jobOrderData['owner_email'],
                CAREERS_OWNERAPPLY_SUBJECT,
                $emailContents
            );


            if ($jobOrderData['owner_email'] != $jobOrderData['recruiter_email'])
            {
                $careerPortalSettings->sendEmail(
                    $automatedUser['userID'],
                    $jobOrderData['recruiter_email'],
                    CAREERS_OWNERAPPLY_SUBJECT,
                    $emailContents
                );
            }
        }
    }

    public function capturePostData($ignore = array())
    {
        $hiddenTags = '';
        $isValidName = function ($name)
        {
            return preg_match('/^[A-Za-z0-9_][A-Za-z0-9_.-]*(\[[A-Za-z0-9_.-]*\])*$/', (string) $name);
        };
        $escapeAttr = function ($value)
        {
            return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
        };
        $appendHiddenTag = function ($name, $value) use (&$hiddenTags, $isValidName, $escapeAttr, &$appendHiddenTag)
        {
            if (!$isValidName($name))
            {
                return;
            }

            if (is_array($value))
            {
                foreach ($value as $key => $item)
                {
                    $appendHiddenTag($name . '[' . $key . ']', $item);
                }
                return;
            }

            $hiddenTags .= sprintf('<input type="hidden" name="%s" value="%s" />%s',
                $name,
                $escapeAttr($value),
                "\n"
            );
        };

        foreach ($_POST as $name => $value)
        {
            if (in_array($name, $ignore)) continue;
            $appendHiddenTag($name, $value);
        }

        if (($uploadFile = FileUtility::getUploadFileFromPost('careerportaladd', 'file')) !== false)
        {
            $fileFieldName = 'file';
            if ($isValidName($fileFieldName))
            {
                $hiddenTags .= sprintf('<input type="hidden" name="%s" value="%s" />%s',
                    $fileFieldName,
                    $escapeAttr($uploadFile),
                    "\n"
                );
            }
        }

        return $hiddenTags;
    }

    private function ProcessCandidateRegistration($template)
    {
        $db = DatabaseConnection::getInstance();

        $numMatches = preg_match_all('/\<input\-([A-Za-z0-9]+)\>/', $template, $matches);
        if (!$numMatches) return false;
        $fields = array();

        foreach ($matches[1] as $tag)
        {
            // Default tags, NOT verification fields
            if (!strcasecmp('submit', $tag) || !strcasecmp('new', $tag) || !strcasecmp('registered', $tag) ||
                !strcasecmp('rememberMe', $tag) || !strcasecmp('captcha', $tag))
            {
                continue;
            }

            if (!isset($_POST[$tag]) || !is_string($_POST[$tag]) || trim($_POST[$tag]) === '')
            {
                return false;
            }
            $fields[$tag] = trim($_POST[$tag]);
        }

        if (empty($fields['email']))
        {
            return false;
        }

        // Get a list of candidate fields to compare against
        $sql = 'SHOW COLUMNS FROM candidate';
        $columns = $db->getAllAssoc($sql);
        for ($i = 0; $i < count($columns); $i++)
        {
            // Convert out of _ notation to camel notation
            $columns[$i]['CamelField'] = str_replace('_', '', $columns[$i]['Field']);
        }

        $verificationFields = 0;
        $sql = 'SELECT candidate_id FROM candidate WHERE ';

        foreach ($fields as $tag => $tagData)
        {
            foreach ($columns as $column => $columnData)
            {
                if (!strcasecmp($columnData['CamelField'], $tag))
                {
                    $sql .= 'LCASE(' . $columnData['Field'] . ') = '
                        . $db->makeQueryString(strtolower($tagData)) . ' AND ';
                    $verificationFields++;
                }
            }
        }

        // There needs to be 1 verification field (equivilant of a "password"), otherwise anyone
        // could change anyone else's candidate information with as little as an e-mail address.
        if ($verificationFields < 1)
        {
            return false;
        }

        $sql .= sprintf('(LCASE(email1) = %s OR LCASE(email2) = %s) LIMIT 1',
            $db->makeQueryString(strtolower($fields['email'])),
            $db->makeQueryString(strtolower($fields['email']))
        );

        $rs = $db->getAssoc($sql);

        if ($db->getNumRows())
        {
            $candidates = new Candidates();
            $candidate = $candidates->get($rs['candidate_id']);

            return $candidate;
        }

        return false;
    }

    private function getRegisteredCandidateBlock($template)
    {
        $candidate = $this->getCareerPortalCandidate();

        if ($candidate !== false)
        {
            return sprintf(
                '<form style="padding:0;margin:0;border:0;" name="logout" id="logout" method="post" '
                . 'action="%s%s"><input type="hidden" id="pa" name="pa" value="" />%s<div style="margin: 20px 0 20px 0; '
                . 'line-height: 18px;"> '
                . '<h3 style="font-weight: normal;"><b>Welcome back %s.</b>&nbsp;&nbsp;Not %s? '
                . '<a href="javascript:void(0);" onclick="document.getElementById(\'pa\').value=\'logout\'; '
                . 'document.logout.submit();">Log Out</a>.'
                . '&nbsp;&nbsp;Need to update your information? <a href="javascript:void(0);" onclick="document.getElementById(\'pa\').value=\'updateProfile\'; '
                . 'document.logout.submit();">Update Profile</a>.'
                . '</h3></div>',
                CATSUtility::getIndexName(),
                $_SERVER['QUERY_STRING'] != '' ? '?' . $_SERVER['QUERY_STRING'] : '',
                $this->capturePostData(array('pa')),
                $candidate['firstName'],
                $candidate['firstName']
            );
        }

        return '';
    }
}

?>
