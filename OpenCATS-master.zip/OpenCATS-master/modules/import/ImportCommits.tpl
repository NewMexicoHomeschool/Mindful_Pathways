<?php TemplateUtility::printHeader('Import', array('modules/import/import.js')); ?>
<?php TemplateUtility::printHeaderBlock(); ?>
<?php TemplateUtility::printTabs($this->active); ?>
    <div id="main">
        <?php TemplateUtility::printQuickSearch(); ?>

        <div id="contents">
            <table>
                <tr>
                    <td width="3%">
                        <img src="images/reports.gif" width="24" height="24" border="0" alt="Import" style="margin-top: 3px;" />&nbsp;
                    </td>
                    <td><h2>Import Data</h2></td>
                </tr>
            </table>

            <?php if (isset($this->successMessage)): ?>

                <p class="note">Success</p>

                <table class="searchTable">
                    <tr>
                        <td>
                            <?php echo($this->successMessage); ?>
                        </td>
                    </tr>
                </table>

                <br />

            <?php endif; ?>

            <p class="note">Pending Commits</p>

            <table class="searchTable">
                <tr>
                    <td>
                        <?php foreach ($this->data as $data): ?>
                            Import #<?php echo($data['importID']); ?> - <?php echo($data['addedLines']); ?> entries added to database.<br />
                            <form method="post" action="<?php echo(CATSUtility::getIndexName()); ?>?m=import&amp;a=revert" style="display:inline;">
                                <input type="hidden" name="postback" value="postback" />
                                <input type="hidden" name="importID" value="<?php echo($data['importID']) ?>" />
                                <input type="submit" value="Revert Import" class="button">
                            </form>
                            <form method="post" action="<?php echo(CATSUtility::getIndexName()); ?>?m=import&amp;a=commit" style="display:inline;">
                                <input type="hidden" name="postback" value="postback" />
                                <input type="hidden" name="importID" value="<?php echo($data['importID']) ?>" />
                                <input type="submit" value="Commit Import" class="button">
                            </form>
                            <input type="button" onclick="document.location.href='<?php echo(CATSUtility::getIndexName()); ?>?m=import&amp;a=viewerrors&amp;importID=<?php echo($data['importID']) ?>';" value="View Errors" class="button">
                            <br /><br />
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
            <br />

            <?php if (isset($this->importErrors)): ?>

                <p class="note">Errors Reported by Import</p>

                <table class="searchTable" width="740">
                    <tr>
                        <td>
                            <?php echo($this->importErrors) ?>
                        </td>
                    </tr>
                </table>
                <form method="post" action="<?php echo(CATSUtility::getIndexName()); ?>?m=import&amp;a=revert" style="display:inline;">
                    <input type="hidden" name="postback" value="postback" />
                    <input type="hidden" name="importID" value="<?php echo($this->importID); ?>" />
                    <input type="submit" value="Revert Import" class="button">
                </form>
                <form method="post" action="<?php echo(CATSUtility::getIndexName()); ?>?m=import&amp;a=commit" style="display:inline;">
                    <input type="hidden" name="postback" value="postback" />
                    <input type="hidden" name="importID" value="<?php echo($this->importID); ?>" />
                    <input type="submit" value="Commit Import" class="button">
                </form>

            <?php endif; ?>

        </div>
    </div>
<?php TemplateUtility::printFooter(); ?>
