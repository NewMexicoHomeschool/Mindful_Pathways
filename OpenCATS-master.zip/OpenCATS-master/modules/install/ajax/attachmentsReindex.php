<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */

include_once(dirname(__DIR__, 3) . '/ajax/bootstrap.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST')
{
    header('Content-Type: text/html; charset=UTF-8');

    $actionURL = htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8');

    echo '<!DOCTYPE html>',
         '<html><head><title>OpenCATS Attachment Reindex</title></head><body>',
         '<p>This maintenance action must be triggered via POST.</p>',
         '<p>This starts the attachment reindex process.</p>',
         '<form method="post" action="', $actionURL, '">',
         '<input type="hidden" name="postback" value="postback" />',
         '<button type="submit">Run maintenance now</button>',
         '</form>',
         '</body></html>';
    die();
}

include_once(LEGACY_ROOT . '/config.php');
include_once(LEGACY_ROOT . '/lib/DatabaseConnection.php');
include_once(LEGACY_ROOT . '/lib/ModuleUtility.php');

if (file_exists('INSTALL_BLOCK'))
{
    $interface = new SecureAJAXInterface();
}

if( ini_get('safe_mode') )
{
	//don't do anything in safe mode
}
else
{
	/* Don't limit the execution time. */
	set_time_limit(0);
}
@ini_set('memory_limit', '256M');

$reindexed = 0;

include_once(LEGACY_ROOT . '/lib/Attachments.php');

if (file_exists('INSTALL_BLOCK') && ($_SESSION['CATS']->getAccessLevel(ACL::SECOBJ_ROOT) < ACCESS_LEVEL_SA))
{
    die('No permision.');
}

$db = DatabaseConnection::getInstance();
 
$rs = $db->getAllAssoc('SELECT attachment_id, directory_name, stored_filename FROM attachment WHERE text = "" OR isnull(text) AND resume = 1');

foreach ($rs as $index => $data)
{
    /* Attempt to reindex file. */
    $storedFilename = './attachments/'.$data['directory_name'].'/'.$data['stored_filename'];
    
    $documentToText = new DocumentToText();
    $documentType = $documentToText->getDocumentType(
        $storedFilename
    );

    $fileContents = @file_get_contents($storedFilename);

    /* If we're creating a file from text contents, we can skip
     * extracting because we already know the text contents.
     */
    if ($fileContents !== false && $documentType == DOCUMENT_TYPE_TEXT)
    {
        $extractedText = $fileContents;
    }
    else if (!file_exists($storedFilename))
    {
        /* Can't extract text from a file that doesn't exist. */
        $extractedText = '';
    }
    else
    {
        $documentToText->convert($storedFilename, $documentType);

        if (!$documentToText->isError())
        {
            $extractedText = $documentToText->getString();
            
            $reindexed++;
            
            $db->query('UPDATE attachment SET text = '.$db->makeQueryString($extractedText).' WHERE attachment_id = '.$data['attachment_id']);
        }
    }
}

echo ($reindexed);

?>
