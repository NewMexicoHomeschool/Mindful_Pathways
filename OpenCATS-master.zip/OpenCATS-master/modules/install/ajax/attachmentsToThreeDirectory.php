<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */

include_once(dirname(__DIR__, 3) . '/ajax/bootstrap.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST')
{
    header('Content-Type: text/html; charset=UTF-8');

    $actionURL = htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8');

    echo '<!DOCTYPE html>',
         '<html><head><title>OpenCATS Attachment Migration</title></head><body>',
         '<p>This maintenance action must be triggered via POST.</p>',
         '<p>This starts the attachment migration to the three-directory layout.</p>',
         '<form method="post" action="', $actionURL, '">',
         '<input type="hidden" name="postback" value="postback" />',
         '<button type="submit">Run maintenance now</button>',
         '</form>',
         '</body></html>';
    die();
}

include_once(LEGACY_ROOT . '/config.php');
include_once(LEGACY_ROOT . '/lib/DatabaseConnection.php');

$interface = new SecureAJAXInterface();

if ($_SESSION['CATS']->getAccessLevel(ACL::SECOBJ_ROOT) < ACCESS_LEVEL_ROOT)
{
    die('No permision.');
}

if( ini_get('safe_mode') )
{
	//don't do anything in safe mode
}
else
{
	/* Don't limit the execution time */
	set_time_limit(0);
}
@ini_set('memory_limit', '256M');

include_once(LEGACY_ROOT . '/lib/Attachments.php');

$db = DatabaseConnection::getInstance();
 
include_once(LEGACY_ROOT . '/lib/Attachments.php');

$db->query('ALTER IGNORE TABLE `attachment` CHANGE `directory_name` `directory_name` VARCHAR(64);');
 
$rs = $db->getAllAssoc('SELECT site_id, attachment_id, directory_name FROM attachment');

foreach ($rs as $index => $data)
{
    if (strpos($data['directory_name'], '/') !== false)
    {
        continue;
    }
    
    $siteDirectory = 'site_'.$data['site_id'];
    $idDirectory = ((int) ($data['attachment_id'] / 1000)) . 'xxx';
    
    $newFileDirectory = './attachments/' . $siteDirectory;
    
    if (!is_dir($newFileDirectory))
    {
        @mkdir($newFileDirectory, 0777);
        
        /* Prevent listing of new directory. */
        @file_put_contents($newFileDirectory . '/index.php', '');
    }

    $newFileDirectory = './attachments/' . $siteDirectory . '/' . $idDirectory;
    
    if (!is_dir($newFileDirectory))
    {
        @mkdir($newFileDirectory, 0777);
        
         /* Prevent listing of new directory. */
        @file_put_contents($newFileDirectory . '/index.php', '');
    }

    $fullDirectoryPath = $newFileDirectory . '/' . $data['directory_name'];
    
    if (@rename('./attachments/' . $data['directory_name'], $fullDirectoryPath) === true)
    {
        $newDirectoryEntry = $siteDirectory.'/'.$idDirectory.'/'.$data['directory_name'];
        $db->query('UPDATE attachment SET directory_name = '.$db->makeQueryString($newDirectoryEntry).' WHERE attachment_id = '.$data['attachment_id']);
    }
}

?>
