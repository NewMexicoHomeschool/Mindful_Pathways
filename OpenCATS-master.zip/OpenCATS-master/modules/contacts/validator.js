/*
 * CATS
 * Candidates Form Validation
 *
 * Copyright (C) 2005 - 2007 Cognizo Technologies, Inc.
 * All rights reserved.
 *
 */

function checkAddForm(form)
{
    var errorMessage = "";

    errorMessage += checkFirstName();
    errorMessage += checkLastName();
    errorMessage += checkCompany();

    if (errorMessage != "")
    {
        alert("Form Error:\n" + errorMessage);
        return false;
    }

    return true;
}

function checkEditForm(form)
{
    var errorMessage = "";

    errorMessage += checkFirstName();
    errorMessage += checkLastName();
    errorMessage += checkCompany();

    if (errorMessage != "")
    {
        alert("Form Error:\n" + errorMessage);
        return false;
    }

    return true;
}

function checkSearchByFullNameForm(form)
{
    var errorMessage = "";

    errorMessage += checkSearchFullName();

    if (errorMessage != "")
    {
        alert("Form Error:\n" + errorMessage);
        return false;
    }

    return true;
}

function checkSearchByCompanyNameForm(form)
{
    var errorMessage = "";

    errorMessage += checkSearchCompanyName();

    if (errorMessage != "")
    {
        alert("Form Error:\n" + errorMessage);
        return false;
    }

    return true;
}

function checkFirstName()
{
    var errorMessage = "";

    fieldValue = document.getElementById("firstName").value;
    fieldLabel = document.getElementById("firstNameLabel");
    if (fieldValue == "")
    {
        errorMessage = "    - You must enter a first name.\n";

        fieldLabel.style.color = "#ff0000";
    }
    else
    {
        fieldLabel.style.color = "#000";
    }

    return errorMessage;
}

function checkLastName()
{
    var errorMessage = "";

    fieldValue = document.getElementById("lastName").value;
    fieldLabel = document.getElementById("lastNameLabel");
    if (fieldValue == "")
    {
        errorMessage = "    - You must enter a last name.\n";

        fieldLabel.style.color = "#ff0000";
    }
    else
    {
        fieldLabel.style.color = "#000";
    }

    return errorMessage;
}

function checkCompany()
{
    var errorMessage = "";

    fieldValue = parseInt(document.getElementById("companyID").value);
    fieldLabel = document.getElementById("companyIDLabel");

    if (isNaN(fieldValue) || fieldValue <= 0)
    {
        errorMessage = "    - You must select a company.\n";

        fieldLabel.style.color = "#ff0000";
    }
    else
    {
        fieldLabel.style.color = "#000";
    }

    return errorMessage;
}

function checkSearchFullName()
{
    var errorMessage = "";

    fieldValue = document.getElementById("wildCardString_fullName").value;
    fieldLabel = document.getElementById("wildCardStringLabel_fullName");
    if (fieldValue == "")
    {
        errorMessage = "    - You must enter some search text.\n";

        fieldLabel.style.color = "#ff0000";
    }
    else
    {
        fieldLabel.style.color = "#000";
    }

    return errorMessage;
}

function checkSearchCompanyName()
{
    var errorMessage = "";

    fieldValue = document.getElementById("wildCardString_companyName").value;
    fieldLabel = document.getElementById("wildCardStringLabel_companyName");
    if (fieldValue == "")
    {
        errorMessage = "    - You must enter some search text.\n";

        fieldLabel.style.color = "#ff0000";
    }
    else
    {
        fieldLabel.style.color = "#000";
    }

    return errorMessage;
}
