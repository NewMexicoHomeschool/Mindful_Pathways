<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */

include_once(LEGACY_ROOT . '/lib/Mailer.php');

/**
 *	Career Portal Settings Library
 *	@package    CATS
 *	@subpackage Library
 */
class CareerPortalSettings
{
    // FIXME: Make this private and use a getter.
    public $requiredTemplateFields = array(
        'Header',
        'Content - Main',
        'Content - Search Results',
        'Content - Job Details',
        'Content - Candidate Registration',
        'Content - Candidate Profile',
        'Content - Apply for Position',
        'Content - Questionnaire',
        'Content - Thanks for your Submission',
        'Footer',
        'CSS'
    );
    private $_db;


    public function __construct()
    {
        $this->_db = DatabaseConnection::getInstance();
    }


    /**
     * Returns all career portal settings and their current values as an
     * associative array.
     *
     * @return array Associative array of all career portal settings and their
     *               current values.
     */
    public function getAll()
    {
        /* Default values. */
        $settings = array(
            'enabled'               => '0', /* false */
            'allowBrowse'           => '1', /* true */
            'candidateRegistration' => '0', /* false */
            'showDepartment'        => '1', /* true */
            'showCompany'           => '0', /* false */
            'activeBoard'           => 'CATS 2.0',
            'allowXMLSubmit'        => '1', /* true */
            'useCATSTemplate'       => ''
        );

        /* Get all career portal settings for this site from the database. */
        $sql = sprintf(
            "SELECT
                settings.setting AS setting,
                settings.value AS value
            FROM
                settings
            WHERE
                settings.settings_type = %s",
            SETTINGS_CAREER_PORTAL
        );
        $rs = $this->_db->getAllAssoc($sql);

        // Override default settings with settings from the database.
        foreach ($rs as $rowIndex => $row)
        {
            if (isset($settings[$id=$row['setting']]))
            {
                $settings[$id] = $row['value'];
            }
        }

        /**
         * Retrieve all setting, value pairs for default or custom template
         * for the activeBoard (if any).
         */
        foreach ($rs as $rowIndex => $row)
        {
            if (!strcmp($row['setting'], 'activeBoard'))
            {
                $activeBoard = $row['value'];

                $templateSource1 = $this->getAllFromDefaultTemplate($activeBoard);
                $templateSource2 = $this->getAllFromCustomTemplate($activeBoard);

                $templateSource = array_merge($templateSource1, $templateSource2);

                foreach ($templateSource as $templateLine)
                {
                    $settings[$templateLine['setting']] = $templateLine['value'];
                }
            }
        }

        return $settings;
    }

    /**
     * Returns all custom template data for a site-specific template name.
     *
     * @param string Template name.
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getAllFromCustomTemplate($template)
    {
        $sql = sprintf(
            "SELECT
                career_portal_template_site.setting AS setting,
                career_portal_template_site.value AS value
            FROM
                career_portal_template_site
            WHERE
                career_portal_template_site.career_portal_name = %s",
            $this->_db->makeQueryString($template)
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all template data for a default template name.
     *
     * @param string Template name.
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getAllFromDefaultTemplate($template)
    {
        $sql = sprintf(
            "SELECT
                career_portal_template.setting AS setting,
                career_portal_template.value AS value
            FROM
                career_portal_template
            WHERE
                career_portal_template.career_portal_name = %s",
            $this->_db->makeQueryString($template)
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all template data for a template name (default OR custom).
     *
     * @param string Template name.
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getAllFromTemplate($template)
    {
        $sql = sprintf(
            "SELECT
                career_portal_template.setting AS setting,
                career_portal_template.value AS value
            FROM
                career_portal_template
            WHERE
                career_portal_template.career_portal_name = %s
            UNION ALL
            SELECT
                career_portal_template_site.setting AS setting,
                career_portal_template_site.value AS value
            FROM
                career_portal_template_site
            WHERE
                career_portal_template_site.career_portal_name = %s",
            $this->_db->makeQueryString($template),
            $this->_db->makeQueryString($template)
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all default template names from the database.
     *
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getDefaultTemplates()
    {
        $sql = sprintf(
            "SELECT
                DISTINCT career_portal_name AS careerPortalName
            FROM
                career_portal_template
            ORDER BY
                career_portal_name ASC"
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all custom template names from the database for this site.
     *
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getCustomTemplates()
    {
        $sql = "SELECT
                DISTINCT career_portal_name AS careerPortalName
            FROM
                career_portal_template_site";

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all template names from the database for this site, including
     * default templates.
     *
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getAllTemplates()
    {
        $sql = sprintf(
            "SELECT
                DISTINCT career_portal_name AS careerPortalName
            FROM
                career_portal_template
            UNION ALL
            SELECT
                DISTINCT career_portal_name AS careerPortalName
            FROM
                career_portal_template_site
            ORDER BY
                careerPortalName ASC"
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all template settings and values from a template (default OR
     * custom).
     *
     * @param string Template name.
     * @return array Multi-dimensional associative result set array of
     *               template data, or array() if no records were
     *               returned.
     */
    public function getTemplate($templateName)
    {
        $rs = $this->getAllFromTemplate($templateName);

        $template = array();
        foreach ($rs as $rowIndex => $row)
        {
            $template[$row['setting']] = $row['value'];
        }

        foreach ($this->requiredTemplateFields as $index => $value)
        {
            if (!isset($template[$value]))
            {
                $template[$value] = '';
            }
        }

        return $template;
    }

    /**
     * Deletes a custom template from the database.
     *
     * @param string Template name.
     * @return boolean Was the query executed successfullu?
     */
    public function deleteCustomTemplate($template)
    {
        $sql = sprintf(
            "DELETE FROM
                career_portal_template_site
            WHERE
                career_portal_name = %s",
            $this->_db->makeQueryString($template)
        );

        return (boolean) $this->_db->query($sql);
    }

    /**
     * Sets a career portal setting for a custom template.
     *
     * @param string Setting name.
     * @param string Setting value.
     * @param string Template name.
     * @return void
     */
    public function setForTemplate($setting, $value, $template)
    {
        $sql = sprintf(
            "DELETE FROM
                career_portal_template_site
            WHERE
                career_portal_template_site.setting = %s
            AND
                career_portal_template_site.career_portal_name = %s",
            $this->_db->makeQueryString($setting),
            $this->_db->makeQueryString($template)
        );
        $this->_db->query($sql);

        $sql = sprintf(
            "INSERT INTO career_portal_template_site (
                setting,
                value,
                career_portal_name
            )
            VALUES (
                %s,
                %s,
                %s
            )",
            $this->_db->makeQueryString($setting),
            $this->_db->makeQueryString($value),
            $this->_db->makeQueryString($template)
         );
         $this->_db->query($sql);
    }

    /**
     * Sets a career portal setting for the current site.
     *
     * @param string Setting name.
     * @param string Setting value.
     * @return void
     */
    public function set($setting, $value)
    {
        /* Delete old setting. */
        $sql = sprintf(
            "DELETE FROM
                settings
            WHERE
                settings.setting = '%s'
            AND
                settings.settings_type = %s",
            SETTINGS_CAREER_PORTAL,
            $this->_db->makeQueryString($setting)
        );
        $this->_db->query($sql);

        /* Add new setting. */
        $sql = sprintf(
            "INSERT INTO settings (
                settings_type,
                setting,
                value
            )
            VALUES (
                %s,
                %s,
                %s
            )",
            SETTINGS_CAREER_PORTAL,
            $this->_db->makeQueryString($setting),
            $this->_db->makeQueryString($value)
         );
         $this->_db->query($sql);
    }

    /**
     * Sends an e-mail.
     *
     * @param integer Current user ID.
     * @param string Destination e-mail address.
     * @param string E-mail subject.
     * @param string E-mail body.
     * @return void
     */
    public function sendEmail($userID, $destination, $subject, $body)
    {
        if (empty($destination))
        {
            return;
        }

        /* Send e-mail notification. */
        //FIXME: Make subject configurable.
        try
        {
            $mailer = new Mailer($userID);
            $mailer->sendToOne(
                array($destination, ''),
                $subject,
                $body,
                true
            );
        }
        catch (\PHPMailer\PHPMailer\Exception $e)
        {
            // Mail not configured or unavailable - log and continue
            error_log(
                'OpenCATS CareerPortal mail error: '
                . get_class($e) . ' [' . $e->getCode() . ']'
            );
        }
    }
}

?>
