<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */

define('ACTIVITY_CALL',        100);
define('ACTIVITY_EMAIL',       200);
define('ACTIVITY_MEETING',     300);
define('ACTIVITY_OTHER',       400);
define('ACTIVITY_CALL_TALKED', 500);
define('ACTIVITY_CALL_LVM',    600);
define('ACTIVITY_CALL_MISSED', 700);
define('ACTIVITY_STATUS_CHANGE', 800);

/**
 * Candidates library.
 */
include_once(LEGACY_ROOT . '/lib/Candidates.php');

/**
 * Contacts library.
 */
include_once(LEGACY_ROOT . '/lib/Contacts.php');

/**
 * Job Orders library.
 */
include_once(LEGACY_ROOT . '/lib/JobOrders.php');


/**
 *  Activity Entries Library
 *  @package    CATS
 *  @subpackage Library
 */
class ActivityEntries
{
    private $_db;
    private $_mysqlDateTimeFormat;


    public function __construct()
    {
        $this->_db = DatabaseConnection::getInstance();

        $is24 = (isset($_SESSION['CATS']) && $_SESSION['CATS']->isTimeFormat24());
        $this->_mysqlDateTimeFormat = DateUtility::getMysqlDateTimeFormat($is24);
    }


    /**
     * Adds an activity entry to the database.
     *
     * @param integer Data Item ID.
     * @param flag Data Item type flag.
     * @param flag Activity type flag.
     * @param string Activity notes.
     * @param integer Entered-by user ID.
     * @param integer Job Order ID; -1 for general (stored as NULL).
     * @param string Date occurred timestamp (YYYY-MM-DD HH:MM:SS); false for NOW().
     * @return integer New Activity ID; -1 on failure.
     */
    public function add($dataItemID, $dataItemType, $activityType,
        $activityNotes, $enteredBy, $jobOrderID = -1, $dateOccurred = false)
    {
        if (!ctype_digit((string) $jobOrderID) || (int) $jobOrderID <= 0)
        {
            $jobOrderID = -1;
        }

        if (is_string($dateOccurred) &&
            preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $dateOccurred))
        {
            $dateOccurredSQL = $this->_db->makeQueryString($dateOccurred);
        }
        else
        {
            $dateOccurredSQL = 'NOW()';
        }

        $sql = sprintf(
            "INSERT INTO activity (
                data_item_id,
                data_item_type,
                joborder_id,
                entered_by,
                type,
                notes,
                date_occurred,
                date_created,
                date_modified
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                NOW(),
                NOW()
            )",
            $this->_db->makeQueryInteger($dataItemID),
            $this->_db->makeQueryInteger($dataItemType),
            $this->_db->makeQueryIntegerOrNULL($jobOrderID),
            $this->_db->makeQueryInteger($enteredBy),
            $this->_db->makeQueryInteger($activityType),
            $this->_db->makeQueryString($activityNotes),
            $dateOccurredSQL
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $activityEntryID = $this->_db->getLastInsertID();

        $history = new History();
        $history->storeHistoryData(
            $dataItemType,
            $dataItemID,
            'ACTIVITY',
            '(NEW)',
            $activityNotes,
            '(USER) Added activity.'
        );

        /* Update the last-modified timestamp for the "parent" Data Item. */
        $this->_updateDataItemModified($dataItemID, $dataItemType);

        /* If there is a job order being associated, update it's modified
         * timestamp, too.
         */
        if (!empty($jobOrderID) && ctype_digit((string) $jobOrderID) &&
            (int) $jobOrderID > 0)
        {
            $this->_updateDataItemModified($jobOrderID, DATA_ITEM_JOBORDER);
        }

        return $activityEntryID;
    }

    /**
     * Updates an activity entry with the information provided.
     *
     * @param integer Activity ID to update.
     * @param flag New activity type flag.
     * @param string New activity notes.
     * @param integer New Job Order ID; -1 for general (stored as NULL).
     * @return boolean True if successful; false otherwise.
     */
    public function update($activityID, $activityType, $activityNotes,
        $jobOrderID, $date, $timezoneOffset)
    {
        /* Get some extra information about the activity entry that we'll
         * need later on.
         */
        $sql = sprintf(
            "SELECT
                activity.data_item_id AS dataItemID,
                activity.data_item_type AS dataItemType,
                activity.joborder_id AS jobOrderID,
                activity.notes AS notes,
                activity.entered_by AS enteredBy,
                CONCAT(
                    user.first_name, ' ', user.last_name
                ) AS enteredByFullName
            FROM
                activity
            LEFT JOIN user AS user
                ON activity.entered_by = user.user_id
            WHERE
                activity.activity_id = %s",
            $this->_db->makeQueryInteger($activityID)
        );
        $activityIDRS = $this->_db->getAssoc($sql);

        if (!$activityIDRS)
        {
            return false;
        }

        /* If a job order ID wasn't specified, use the existing one. */
        if ($jobOrderID === false)
        {
            $newJobOrderID = $activityIDRS['jobOrderID'];
        }
        else
        {
            $newJobOrderID = $jobOrderID;
        }

        if (!ctype_digit((string) $newJobOrderID) || (int) $newJobOrderID <= 0)
        {
            $newJobOrderID = -1;
        }

        $sql = sprintf(
            "UPDATE
                activity
            SET
                type          = %s,
                notes         = %s,
                joborder_id   = %s,
                date_modified = NOW()
            WHERE
                activity_id = %s",
            $this->_db->makeQueryInteger($activityType),
            $this->_db->makeQueryString($activityNotes),
            $this->_db->makeQueryIntegerOrNULL($newJobOrderID),
            $this->_db->makeQueryInteger($activityID)
        );
        $queryResult = $this->_db->query($sql);

        if ($date !== false)
        {
            $sql = sprintf(
                "UPDATE
                    activity
                SET
                    date_occurred = DATE_SUB(%s, INTERVAL %s HOUR),
                    date_modified = NOW()
                WHERE
                    activity_id = %s",
                $this->_db->makeQueryString($date),
                $this->_db->makeQueryInteger($timezoneOffset),
                $this->_db->makeQueryInteger($activityID)
            );

            $queryResult = $this->_db->query($sql);
        }

        $history = new History();
        $history->storeHistoryData(
            $activityIDRS['dataItemType'],
            $activityIDRS['dataItemID'],
            'ACTIVITY',
            $activityIDRS['notes'],
            $activityNotes,
            '(USER) Edited ' . $activityIDRS['enteredByFullName'] . '\'s activity.'
        );

        if (!$queryResult)
        {
            return false;
        }

        /* Update the last-modified timestamp for the "parent" Data Item. */
        $this->_updateDataItemModified(
            $activityIDRS['dataItemID'], $activityIDRS['dataItemType']
        );

        /* If there is a job order being associated, update it's modified
         * timestamp, too.
         */
        if (!empty($jobOrderID) && ctype_digit((string) $jobOrderID) &&
            (int) $jobOrderID > 0)
        {
            $this->_updateDataItemModified($jobOrderID, DATA_ITEM_JOBORDER);
        }

        /* The job order ID may have been changed. If it has, and the new one
         * is valid, update its modified timestamp, too.
         */
        if (!empty($newJobOrderID) && ctype_digit((string) $newJobOrderID) &&
            (int) $newJobOrderID > 0 && $jobOrderID != $newJobOrderID)
        {
            $this->_updateDataItemModified($newJobOrderID, DATA_ITEM_JOBORDER);
        }

        return true;
    }

    /**
     * Removes an activity note from the system.
     *
     * @param integer Activity ID.
     * @return boolean True if successful; false otherwise.
     */
    public function delete($activityID)
    {
        $sql = sprintf(
            "SELECT
                activity.data_item_id AS dataItemID,
                activity.data_item_type AS dataItemType,
                activity.joborder_id AS jobOrderID,
                activity.notes AS notes,
                activity.entered_by AS enteredBy,
                CONCAT(
                    user.first_name, ' ', user.last_name
                ) AS enteredByFullName
            FROM
                activity
            LEFT JOIN user AS user
                ON activity.entered_by = user.user_id
            WHERE
                activity.activity_id = %s",
            $this->_db->makeQueryInteger($activityID)
        );
        $activityIDRS = $this->_db->getAssoc($sql);

        if (!$activityIDRS)
        {
            return false;
        }

        $sql = sprintf(
            "DELETE FROM
                activity
            WHERE
                activity_id = %s",
            $this->_db->makeQueryInteger($activityID)
        );
        $queryResult = $this->_db->query($sql);

        if (!$queryResult)
        {
            return false;
        }

        $history = new History();
        $history->storeHistoryData(
            $activityIDRS['dataItemType'],
            $activityIDRS['dataItemID'],
            'ACTIVITY',
            $activityIDRS['notes'],
            '(DELETE)',
            '(USER) Deleted ' . $activityIDRS['enteredByFullName'] . '\'s activity.'
        );

        /* Update the last-modified timestamp for the "parent" Data Item. */
        $this->_updateDataItemModified(
            $activityIDRS['dataItemID'], $activityIDRS['dataItemType']
        );

        /* If there is a job order associated, update it's modified timestamp,
         * too.
         */
        if (!empty($activityIDRS['jobOrderID']) &&
            ctype_digit((string) $activityIDRS['jobOrderID']))
        {
            $this->_updateDataItemModified(
                $activityIDRS['jobOrderID'], DATA_ITEM_JOBORDER
            );
        }

        return true;
    }

    /**
     * Returns number of total activities (for activities datagrid).
     *
     * @return integer count
     */
    public function getCount()
    {
        $sql = "SELECT
                COUNT(*) AS totalActivities
            FROM
                activity";

        return $this->_db->getColumn($sql, 0, 0);
    }

    /**
     * Returns an activity entry.
     *
     * @param integer Activity ID.
     * @return array Activity data.
     */
    public function get($activityID)
    {
        $sql = sprintf(
            "SELECT
                activity.activity_id AS activityID,
                activity.data_item_id AS dataItemID,
                activity.data_item_type AS dataItemType,
                activity.joborder_id AS jobOrderID,
                activity.type AS type,
                activity_type.short_description AS typeDescription,
                activity.notes AS notes,
                DATE_FORMAT(
                    activity.date_occurred, '" . $this->_mysqlDateTimeFormat . "'
                ) AS dateCreated,
                entered_by_user.first_name AS enteredByFirstName,
                entered_by_user.last_name AS enteredByLastName,
                IF(
                    ISNULL(joborder.title),
                    'General',
                    CONCAT(joborder.title, ' (', company.name, ')')
                ) AS regarding,
                joborder.title AS regardingJobTitle,
                company.name AS regardingCompanyName
            FROM
                activity
            LEFT JOIN activity_type
                ON activity.type = activity_type.activity_type_id
            LEFT JOIN user AS entered_by_user
                ON activity.entered_by = entered_by_user.user_id
            LEFT JOIN joborder
                ON activity.joborder_id = joborder.joborder_id
            LEFT JOIN company
                ON joborder.company_id = company.company_id
            WHERE
                activity.activity_id = %s",
            $this->_db->makeQueryInteger($activityID)
        );

        return $this->_db->getAssoc($sql);
    }

    /**
     * Apply the parent module's existing activity permissions, not authorship.
     */
    public function canModify($activity, $delete = false)
    {
        if (empty($activity) || empty($activity['dataItemID']))
        {
            return false;
        }

        switch ($activity['dataItemType'])
        {
            case DATA_ITEM_CANDIDATE:
                $module = 'candidates';
                $permission = $delete ? 'candidates.delete' : 'candidates.edit';
                $requiredLevel = $delete ? ACCESS_LEVEL_DELETE : ACCESS_LEVEL_EDIT;
                break;

            case DATA_ITEM_CONTACT:
                $module = 'contacts';
                $permission = $delete ? 'contacts.deleteActivity' : 'contacts.editActivity';
                $requiredLevel = ACCESS_LEVEL_EDIT;
                break;

            default:
                // Normal activity UI supports candidates and contacts only.
                // The company page aggregates its contacts' activities.
                return false;
        }

        if ($_SESSION['CATS']->getAccessLevel($permission) < $requiredLevel ||
            $_SESSION['CATS']->getAccessLevel($module . '.show') < ACCESS_LEVEL_READ)
        {
            return false;
        }

        if ($activity['dataItemType'] == DATA_ITEM_CANDIDATE)
        {
            include_once(LEGACY_ROOT . '/lib/CandidateAuthorization.php');
            return CandidateAuthorization::canAccessCandidate($activity['dataItemID']);
        }

        $contacts = new Contacts();
        return !empty($contacts->get($activity['dataItemID']));
    }

    /**
     * Returns all activity entries for a Data Item.
     *
     * @param integer Data Item ID.
     * @param flag Data Item type flag.
     * @return resultset Activity entries data.
     */
    public function getAllByDataItem($dataItemID, $dataItemType)
    {
        $sql = sprintf(
            "SELECT
                activity.activity_id AS activityID,
                activity.data_item_id AS dataItemID,
                activity.joborder_id AS jobOrderID,
                activity.notes AS notes,
                DATE_FORMAT(
                    activity.date_occurred, '" . $this->_mysqlDateTimeFormat . "'
                ) AS dateCreated,
                activity.date_occurred AS dateCreatedSort,
                activity.type AS type,
                activity_type.short_description AS typeDescription,
                entered_by_user.first_name AS enteredByFirstName,
                entered_by_user.last_name AS enteredByLastName,
                IF(
                    ISNULL(joborder.title),
                    'General',
                    CONCAT(joborder.title, ' (', company.name, ')')
                ) AS regarding,
                joborder.title AS regardingJobTitle,
                company.name AS regardingCompanyName
            FROM
                activity
            LEFT JOIN user AS entered_by_user
                ON activity.entered_by = entered_by_user.user_id
            LEFT JOIN activity_type
                ON activity.type = activity_type.activity_type_id
            LEFT JOIN joborder
                ON activity.joborder_id = joborder.joborder_id
            LEFT JOIN company
                ON joborder.company_id = company.company_id
            WHERE
                activity.data_item_id = %s
            AND
                activity.data_item_type = %s
            ORDER BY
                dateCreatedSort DESC,
                activity.activity_id DESC",
            $this->_db->makeQueryInteger($dataItemID),
            $this->_db->makeQueryInteger($dataItemType)
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all activity entries for contacts belonging to a company.
     *
     * @param integer Company ID.
     * @return resultset Activity entries data.
     */
    public function getAllByCompany($companyID)
    {
        $sql = sprintf(
            "SELECT
                activity.activity_id AS activityID,
                activity.data_item_id AS dataItemID,
                activity.joborder_id AS jobOrderID,
                activity.notes AS notes,
                DATE_FORMAT(
                    activity.date_occurred, '" . $this->_mysqlDateTimeFormat . "'
                ) AS dateCreated,
                activity.date_occurred AS dateCreatedSort,
                activity.type AS type,
                activity_type.short_description AS typeDescription,
                entered_by_user.first_name AS enteredByFirstName,
                entered_by_user.last_name AS enteredByLastName,
                contact.contact_id AS contactID,
                contact.first_name AS contactFirstName,
                contact.last_name AS contactLastName,
                IF(
                    ISNULL(joborder.title),
                    'General',
                    CONCAT(joborder.title, ' (', company.name, ')')
                ) AS regarding,
                joborder.title AS regardingJobTitle,
                company.name AS regardingCompanyName
            FROM
                activity
            LEFT JOIN user AS entered_by_user
                ON activity.entered_by = entered_by_user.user_id
            LEFT JOIN activity_type
                ON activity.type = activity_type.activity_type_id
            LEFT JOIN joborder
                ON activity.joborder_id = joborder.joborder_id
            LEFT JOIN company
                ON joborder.company_id = company.company_id
            INNER JOIN contact
                ON activity.data_item_id = contact.contact_id
            WHERE
                contact.company_id = %s
            AND
                activity.data_item_type = %s
            ORDER BY
                dateCreatedSort DESC,
                activity.activity_id DESC",
            $this->_db->makeQueryInteger($companyID),
            $this->_db->makeQueryInteger(DATA_ITEM_CONTACT)
        );

        return $this->_db->getAllAssoc($sql);
    }

    /**
     * Returns all activity types and their descriptions.
     *
     * @return resultset Activity type IDs and descriptions.
     */
    public function getTypes()
    {
        $sql = "SELECT
                activity_type_id AS typeID,
                short_description AS type
            FROM
                activity_type
            ORDER BY
                activity_type_id DESC";

        return $this->_db->getAllAssoc($sql);
    }


    /**
     * Updates a Data Item's modified timestamp.
     *
     * @param integer Data Item ID.
     * @param flag Data Item type flag.
     * @return void
     */
    private function _updateDataItemModified($dataItemID, $dataItemType)
    {
        switch ($dataItemType)
        {
            case DATA_ITEM_CANDIDATE:
                $dataItem = new Candidates();
                break;

            case DATA_ITEM_COMPANY:
                $dataItem = new Companies();
                break;

            case DATA_ITEM_CONTACT:
                $dataItem = new Contacts();
                break;

            case DATA_ITEM_JOBORDER:
                $dataItem = new JobOrders();
                break;

            default:
                return;
                break;
        }

        $dataItem->updateModified($dataItemID);
    }
}

?>
