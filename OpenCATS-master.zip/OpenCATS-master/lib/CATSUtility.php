<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */

// FIXME: Why is this being reincluded here?
include_once(LEGACY_ROOT . '/config.php');
include_once(LEGACY_ROOT . '/lib/FileUtility.php');

/**
 *	General Utility Library
 *	@package    CATS
 *	@subpackage Library
 */
class CATSUtility
{
    /* Prevent this class from being instantiated. */
    private function __construct() {}
    private function __clone() {}


    /**
     * Returns the current CATS version string from the .version file in the
     * CATS root directory.
     *
     * @return string CATS version information.
     */
    public static function getVersion()
    {
        return CATS_VERSION;
    }

    /**
     * Returns the current CATS version number as an integer of the format
     * "MMmmpp", where MM is the major version number, mm is the minor version
     * number, and pp is the patchlevel. For example, 0.5.5 would be 505, and
     * 1.13.6 would be 11306.
     *
     * @return integer CATS version number.
     */
    public static function getVersionAsInteger()
    {
        $versionString = CATS_VERSION;

        /* Remove anything after (and including) the first space from the
         * version data.
         */
        $spacePosition = strpos($versionString, ' ');
        if ($spacePosition !== false)
        {
            $versionString = substr($versionString, 0, $spacePosition);
        }

        /* Multiply each version part (Major.Minor.Patchlevel) by a constant
         * to create an integer in which newer versions are always greater
         * mathematically than older versions.
         */
        $versionIntegers = explode('.', $versionString);
        $versionInteger =  $versionIntegers[0] * 10000;
        $versionInteger += $versionIntegers[1] * 100;
        $versionInteger += $versionIntegers[2] * 1;

        return $versionInteger;
    }

    /**
     * Returns the current CATS revision number from SVN metadata.
     *
     * @return integer CATS SVN revision or 0 if no metadata exists.
     */
    public static function getBuild()
    {
        if (!file_exists('.svn/entries'))
        {
            return 0;
        }

        $data = @file_get_contents('.svn/entries');

        /* XML Data? */
        if ($data[0] === '<')
        {
            $xml = @simplexml_load_string($data);
            if (!$xml || !isset($xml->entry[0]['committed-rev']))
            {
                return 0;
            }

            return (int) $xml->entry[0]['committed-rev'];
        }

        /* If the data is not XML, there is a version number at the first
         * character of the string. We can handle versions 7 and 8.
         */
        if ((int) $data[0] > 6 && (int) $data[0] < 9)
        {
            /* Return the text between the end of the first "dir" line and
             * the next linefeed.
             */
            $data = substr($data, strpos($data, "dir\n") + 4);
            $data = substr($data, 0, strpos($data, "\n"));

            return (int) $data;
        }
    }

    /**
     * Modifies a setting in config.php (actually modifies the file). String
     * settings need to actually be enclosed in quotes.
     *
     * @param string Name of setting to modify.
     * @param string New value to assign to setting.
     * @return boolean Was the setting changed successfully?
     */
    public static function changeConfigSetting($name, $value)
    {
        /* Make sure we can read and write to config.php. */
        if (!is_readable('config.php') || !is_writeable('config.php'))
        {
            return false;
        }

        /* Try to read the existing config file. */
        $config = @file('config.php');
        if ($config === false)
        {
            return false;
        }

        $newconfig = array();
        foreach ($config as $index => $line)
        {
            if (strpos($line, 'define(\'' . $name . '\'') === 0)
            {
                $newconfig[] = sprintf("define('%s', %s);", $name, $value);
            }
            else
            {
                $newconfig[] = rtrim($line);
            }
        }

        $result = @file_put_contents(
            'config.php',
            implode("\n", $newconfig) . "\n"
        );

        if (!$result)
        {
            /* We either completely failed or wrote 0 bytes. */
            return false;
        }

        /*
         * Ensure subsequent requests see the updated configuration immediately
         * when PHP OPcache is enabled.
         */
        if (function_exists('opcache_invalidate'))
        {
            $configPath = realpath('config.php');

            if ($configPath !== false)
            {
                opcache_invalidate($configPath, true);
            }
        }

        return true;
    }

    /**
     * Returns the current GET query string with all GET variables in $remove
     * removed. The resulting parameter string is separated by $separator.
     *
     * @param array GET variable names to remove.
     * @param array GET variable separator.
     * @return string Filtered GET query string.
     */
    public static function getFilteredGET($remove = array(), $separator = '&')
    {
        $getVars = $_GET;

        foreach ($remove as $name)
        {
            if (isset($getVars[$name]))
            {
                unset($getVars[$name]);
            }
        }

        $newParameters = array();
        foreach ($getVars as $name => $value)
        {
            $newParameters[] = urlencode($name) . '=' . urlencode($value);
        }

        return implode($separator, $newParameters);
    }

    /**
     * Sanitizes an HTML fragment using a strict allowlist.
     *
     * @param string $html HTML fragment to sanitize.
     * @return string Sanitized HTML fragment.
     */
    public static function sanitizeHtmlAllowlist($html)
    {
        if ($html === null)
        {
            return '';
        }

        $html = (string) $html;
        if ($html === '')
        {
            return '';
        }

        $allowedTags = array(
            'p' => true, 'br' => true, 'div' => true, 'span' => true,
            'strong' => true, 'b' => true, 'em' => true, 'i' => true, 'u' => true, 's' => true,
            'ul' => true, 'ol' => true, 'li' => true,
            'blockquote' => true, 'pre' => true, 'code' => true, 'hr' => true,
            'h1' => true, 'h2' => true, 'h3' => true, 'h4' => true, 'h5' => true, 'h6' => true,
            'table' => true, 'thead' => true, 'tbody' => true, 'tr' => true, 'th' => true, 'td' => true,
            'a' => true
        );
        $dropTags = array(
            'script' => true, 'style' => true, 'iframe' => true, 'object' => true,
            'embed' => true, 'svg' => true, 'math' => true
        );
        $allowedAttrsGlobal = array('class' => true, 'title' => true);
        $allowedAttrsByTag = array(
            'a' => array('href' => true, 'title' => true, 'target' => true, 'rel' => true)
        );

        $dom = new DOMDocument();
        $previousUseInternal = libxml_use_internal_errors(true);
        /* Ensure DOMDocument parses the HTML fragment as UTF-8. */
        $wrappedHtml = '<?xml encoding="UTF-8"><div>' . $html . '</div>';
        $flags = 0;
        if (defined('LIBXML_HTML_NOIMPLIED'))
        {
            $flags |= LIBXML_HTML_NOIMPLIED;
        }
        if (defined('LIBXML_HTML_NODEFDTD'))
        {
            $flags |= LIBXML_HTML_NODEFDTD;
        }
        if ($flags)
        {
            $loaded = $dom->loadHTML($wrappedHtml, $flags);
        }
        else
        {
            $loaded = $dom->loadHTML($wrappedHtml);
        }
        libxml_clear_errors();
        libxml_use_internal_errors($previousUseInternal);
        if ($loaded === false)
        {
            return htmlspecialchars((string) $html, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
        }

        $container = $dom->getElementsByTagName('div')->item(0);
        if ($container === null)
        {
            return htmlspecialchars((string) $html, ENT_QUOTES | ENT_SUBSTITUTE, HTML_ENCODING);
        }

        $sanitizeNode = function ($node) use (&$sanitizeNode, $allowedTags, $dropTags, $allowedAttrsGlobal, $allowedAttrsByTag)
        {
            for ($child = $node->firstChild; $child !== null; $child = $next)
            {
                $next = $child->nextSibling;

                if ($child->nodeType !== XML_ELEMENT_NODE)
                {
                    continue;
                }

                $tagName = strtolower($child->nodeName);
                if (!isset($allowedTags[$tagName]))
                {
                    if (isset($dropTags[$tagName]))
                    {
                        $node->removeChild($child);
                        continue;
                    }

                    $promoted = $child->firstChild;
                    while ($child->firstChild !== null)
                    {
                        $node->insertBefore($child->firstChild, $child);
                    }
                    $node->removeChild($child);
                    if ($promoted !== null)
                    {
                        $next = $promoted;
                    }
                    continue;
                }

                if ($child->hasAttributes())
                {
                    for ($i = $child->attributes->length - 1; $i >= 0; $i--)
                    {
                        $attr = $child->attributes->item($i);
                        if ($attr === null)
                        {
                            continue;
                        }
                        $attrName = strtolower($attr->name);
                        if (strpos($attrName, 'on') === 0 || $attrName === 'style')
                        {
                            $child->removeAttributeNode($attr);
                            continue;
                        }
                        $allowed = isset($allowedAttrsGlobal[$attrName]);
                        if (!$allowed && isset($allowedAttrsByTag[$tagName][$attrName]))
                        {
                            $allowed = true;
                        }
                        if (!$allowed)
                        {
                            $child->removeAttributeNode($attr);
                        }
                    }
                }

                if ($tagName === 'a')
                {
                    if ($child->hasAttribute('href'))
                    {
                        $href = trim($child->getAttribute('href'));
                        $isUnsafe = false;
                        if (preg_match('/^\s*javascript:/i', $href))
                        {
                            $isUnsafe = true;
                        }
                        else if (preg_match('/^\s*[a-z][a-z0-9+\-.]*:/i', $href) &&
                            !preg_match('/^\s*(https?|mailto|tel):/i', $href))
                        {
                            $isUnsafe = true;
                        }
                        if ($isUnsafe)
                        {
                            $child->removeAttribute('href');
                        }
                        else
                        {
                            $child->setAttribute('href', $href);
                        }
                    }

                    if ($child->hasAttribute('target') && !strcasecmp($child->getAttribute('target'), '_blank'))
                    {
                        $rel = $child->getAttribute('rel');
                        $relParts = preg_split('/\s+/', trim($rel));
                        $relParts = array_filter($relParts, 'strlen');
                        $relLower = array();
                        foreach ($relParts as $part)
                        {
                            $relLower[strtolower($part)] = true;
                        }
                        if (!isset($relLower['noopener']))
                        {
                            $relParts[] = 'noopener';
                        }
                        if (!isset($relLower['noreferrer']))
                        {
                            $relParts[] = 'noreferrer';
                        }
                        $child->setAttribute('rel', trim(implode(' ', $relParts)));
                    }
                }

                $sanitizeNode($child);
            }
        };

        $sanitizeNode($container);

        $output = '';
        for ($child = $container->firstChild; $child !== null; $child = $child->nextSibling)
        {
            $output .= $dom->saveHTML($child);
        }

        return $output;
    }

    /**
     * Returns the "absolute" version of a URI that is relative to the CATS
     * root directory.
     *
     * FIXME: Allow configuration override of HTTP_HOST.
     *
     * @param string Relative URI.
     * @return string Absolute URI.
     */
    public static function getAbsoluteURI($relativePath = '')
    {
        //FIXME: This causes problems on IIS. Check forums for reporters. bradoyler and one more...
        if (!isset($_SERVER['HTTPS']) || empty($_SERVER['HTTPS']) ||
            strtolower($_SERVER['HTTPS']) != 'on')
        {
            $absoluteURI  = 'http://';
        }
        else
        {
            $absoluteURI  = 'https://';
        }

        $absoluteURI .= $_SERVER['HTTP_HOST']
            . str_replace('\\', '/', dirname($_SERVER['PHP_SELF'])) . '/';

        // This breaks stuff. FIXME http://www.catsone.com/bugs/?do=details&task_id=72
        // if (!eval(Hooks::get('CATS_UTILITY_GET_INDEX_URL'))) return;

        $absoluteURI .= $relativePath;

        /* Clean up extra /'s. */
        $absoluteURI = str_replace('//', '/', $absoluteURI);
        $absoluteURI = str_replace('http:/',  'http://',  $absoluteURI);
        $absoluteURI = str_replace('https:/', 'https://', $absoluteURI);

        return $absoluteURI;
    }

    /**
     * Transfers, via a Location: header, the "absolute" version of a URI that
     * is relative to index.php?.
     *
     * @param string Relative URI.
     * @return void
     */
    public static function transferRelativeURI($relativePath)
    {
        $newLocation = self::getAbsoluteURI(
            CATSUtility::getIndexName() . '?' . $relativePath
        );

        self::transferURL($newLocation);
    }

    /**
     * Transfers, via a Location: header, to an URL.
     *
     * @param string URL.
     * @return void
     */
    public static function transferURL($URL)
    {
        session_write_close();

        header('Location: ' . $URL);

        die();
    }

    /**
     * Returns the full public URL to the CATS root directory.
     *
     * @return string URL.
     */
    public static function getNonSSLDirectoryURL()
    {
        // FIXME: Make this work with ajax.php

        $parts = explode('/', $_SERVER['PHP_SELF']);

        unset($parts[count($parts) - 1]);

        $directory = implode('/', $parts);

        return 'http://' . $_SERVER['HTTP_HOST'] . $directory . '/';
    }

    /**
     * Returns the name of the PHP file that is being used as CATS's delegation
     * module. Usually index.php, but can be index.php5, or anything really.
     *
     * @return string Filename of index.php.
     */
    public static function getIndexName()
    {
        /* This shouldn't happen, but try to recover gracefully if it does. */
        if (!isset($_SERVER['PHP_SELF']))
        {
            return 'index.php';
        }

        $parts = explode('/', $_SERVER['PHP_SELF']);
        $index = end($parts);

        /* Handle ajax.php. */
        $indexParts = explode('.', $index);
        if ($indexParts[0] == 'ajax')
        {
            if (isset($indexParts[1]) && $indexParts[1] !== '')
            {
                $index = 'index.' . $indexParts[1];
            }
            else
            {
                $index = 'index.php';
            }
        }

        /* Older versions of apache sometimes don't concatinate script name by default. */
        if ($index == '')
        {
            return 'index.php';
        }

        if (!preg_match('/^[A-Za-z0-9_.-]+$/', $index))
        {
            return 'index.php';
        }

        return $index;
    }

    /**
     * Returns the directory CATS is being executed from,
     *
     * @return string directory containing index.php.
     */
    public static function getDirectoryName()
    {
        $parts = explode('/', $_SERVER['PHP_SELF']);
        unset ($parts[count($parts)-1]);

        $directory = implode('/', $parts);

        return $directory;
    }

    /**
     * Returns the full URL of the PHP file that is being used as CATS's
     * delegation module. Usually index.php, but can be index.php5, or
     * anything really. This forces 'http://' even if we are really using
     * HTTPS.
     *
     * @return string Full URL of index.php.
     */
    public static function getNonSSLIndexURL()
    {
        $parts = explode('/', $_SERVER['PHP_SELF']);
        unset($parts[count($parts) - 1]);

        $parts[] = self::getIndexName();
        $path = implode('/', $parts);

        $url = sprintf('http://%s%s', $_SERVER['HTTP_HOST'], $path);

        /* Fixes for CATS production server. */
        $url = str_replace('catsone.net', 'catsone.com', $url);
        $url = str_replace('http://catsone.com', 'http://www.catsone.com', $url);

        return $url;
    }

    /**
     * Returns the full URL of the PHP file that is being used as CATS's
     * delegation module. Usually index.php, but can be index.php5, or
     * anything really. This will use 'https://' if enabled.
     *
     * @param FIXME DOCUMENT ME
     * @return string Full URL of index.php.
     */
    public static function getSSLIndexURL($cutTopDir = false)
    {
        if (!SSL_ENABLED || !isset($_SERVER['HTTP_HOST']))
        {
            return self::getIndexName();
        }

        // FIXME: Document / clean up cut top dir stuff.
        if ($cutTopDir)
        {
            $dirs = explode('/', $_SERVER['PHP_SELF']);
            $path = '/' . implode('/', array_slice($dirs, 1, -2)) . '/' . implode('/', array_slice($dirs, -1, 1));
        }
        else
        {
            $path = $_SERVER['PHP_SELF'];
        }

        $url = sprintf('https://%s%s', $_SERVER['HTTP_HOST'], $path);

        /* Fixes for CATS production server. */
        $url = str_replace('catsone.net', 'catsone.com', $url);
        $url = str_replace('https://catsone.com', 'https://www.catsone.com', $url);

        return $url;
    }

    /**
     * Prints Network Solutions' SSL seal.
     *
     * @return void
     */
    public static function printSSLSeals()
    {
        // FIXME: Maybe I go in TemplateUtility?

        echo '<div style="text-align: left; width: 100%; padding: 20px 0px 0px 0px;">';
        echo '<script src="https://seal.networksolutions.com/siteseal/javascript/siteseal.js" type="text/javascript"></script>';
        echo '<script type="text/javascript">';
        echo 'SiteSeal("https://seal.networksolutions.com/images/basicsqgreen.gif", "NETSB", "none");';
        echo '</script>';
        echo '</div>';
    }

    /**
     * Checks to see if SSL is enabled.
     *
     * @return boolean Is SSL enabled?
     */
    public static function isSSL()
    {
        if (isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on')
        {
            return true;
        }

        return false;
    }

    /**
     * Returns true of the SOAP extension is installed.
     *
     * @return boolean Is the SOAP extension installed?
     */
    public static function isSOAPEnabled()
    {
        if (extension_loaded('soap') && class_exists('SoapClient'))
        {
            return true;
        }

        return false;
    }
}

?>
