<?php
/*
 * OpenCATS
 *
 * Portions Copyright (C) 2005-2007 Cognizo Technologies, Inc.
 * Originally released as part of CATS Standard Edition under the
 * CATS Public License 1.1a.
 *
 * See LICENSE.md.
 */


include_once('./config.php');
include_once(LEGACY_ROOT . '/constants.php');
include_once(LEGACY_ROOT . '/lib/DatabaseConnection.php');
include_once(LEGACY_ROOT . '/lib/Session.php'); /* Depends: MRU, Users, DatabaseConnection. */
include_once(LEGACY_ROOT . '/lib/AJAXInterface.php');
include_once(LEGACY_ROOT . '/lib/CATSUtility.php');
include_once(LEGACY_ROOT . '/lib/SchemaMigrationStatus.php');


header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

/* Only start a session for POST requests so CSRF validation can determine logged-in state. */
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST')
{
    @session_name(CATS_SESSION_NAME);
    session_start();
}

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_SESSION['CATS']) && $_SESSION['CATS']->isLoggedIn())
{
    $token = null;

    if (isset($_POST['csrfToken']))
    {
        $token = $_POST['csrfToken'];
    }

    if (!$_SESSION['CATS']->isCSRFTokenValid($token))
    {
        header('Content-type: text/xml');
        echo '<?xml version="1.0" encoding="', AJAX_ENCODING, '"?>', "\n";
        echo(
            "<data>\n" .
            "    <errorcode>-1</errorcode>\n" .
            "    <errormessage>Invalid request.</errormessage>\n" .
            "</data>\n"
        );

        die();
    }
}

if (!isset($_REQUEST['f']) || empty($_REQUEST['f']))
{
    header('Content-type: text/xml; charset=' . AJAX_ENCODING);
    echo '<?xml version="1.0" encoding="', AJAX_ENCODING, '"?>', "\n";
    echo(
        "<data>\n" .
        "    <errorcode>-1</errorcode>\n" .
        "    <errormessage>No function specified.</errormessage>\n" .
        "</data>\n"
    );

    die();
}

$installerActive = (!file_exists('INSTALL_BLOCK'));
if ($installerActive)
{
    $module = '';
    if (strpos($_REQUEST['f'], ':') !== false)
    {
        $parameters = explode(':', $_REQUEST['f']);
        $module = preg_replace("/[^A-Za-z0-9]/", "", $parameters[0]);
    }

    if ($module !== 'install')
    {
        header('Content-type: text/xml');
        echo '<?xml version="1.0" encoding="', AJAX_ENCODING, '"?>', "\n";
        echo(
            "<data>\n" .
            "    <errorcode>-1</errorcode>\n" .
            "    <errormessage>Installer is active. Only installer AJAX actions are allowed.</errormessage>\n" .
            "</data>\n"
        );

        die();
    }
}

$module = '';

if (strpos($_REQUEST['f'], ':') === false)
{
    $function = preg_replace("/[^A-Za-z0-9]/", "", $_REQUEST['f']);
    
    $filename = sprintf('ajax/%s.php', $function);
}
else
{
    /* Split function parameter into module name and function name. */
    $parameters = explode(':', $_REQUEST['f']);
    
    $module = preg_replace("/[^A-Za-z0-9]/", "", $parameters[0]);
    $function = preg_replace("/[^A-Za-z0-9]/", "", $parameters[1]);
    
    $filename = sprintf('modules/%s/ajax/%s.php', $module, $function);
}

/* Fresh installer AJAX remains available. On installed systems, only the
 * existing maintenance action may pass the pending-migration AJAX gate.
 */
$maintenanceAJAXAllowed =
    $installerActive ||
    ($module === 'install' && $function === 'maint');

if (isset($_SESSION['CATS']) &&
    $_SESSION['CATS']->isLoggedIn() &&
    !$maintenanceAJAXAllowed &&
    SchemaMigrationStatus::hasPendingInstallMigrations())
{
    header('Content-type: text/xml; charset=' . AJAX_ENCODING);
    echo '<?xml version="1.0" encoding="', AJAX_ENCODING, '"?>', "\n";
    echo(
        "<data>\n" .
        "    <errorcode>-1</errorcode>\n" .
        "    <errormessage>Database maintenance is required.</errormessage>\n" .
        "</data>\n"
    );

    die();
}

if (!is_readable($filename))
{
    header('Content-type: text/xml; charset=' . AJAX_ENCODING);
    echo '<?xml version="1.0" encoding="', AJAX_ENCODING, '"?>', "\n";
    echo(
        "<data>\n" .
        "    <errorcode>-1</errorcode>\n" .
        "    <errormessage>Invalid function name.</errormessage>\n" .
        "</data>\n"
    );

    die();
}

$filters = array();

if (!isset($_REQUEST['nobuffer']))
{
    include_once(LEGACY_ROOT . '/lib/Hooks.php');

    ob_start();
    include($filename);
    $output = ob_get_clean();

    if (!eval(Hooks::get('AJAX_HOOK'))) return;

    if (!isset($_REQUEST['nospacefilter']))
    {
        $output = preg_replace('/^\s+/m', '', $output);
    }

    foreach ($filters as $filter)
    {
        eval($filter);
    }

    echo($output);
}
else
{
    include($filename);
}


?>
